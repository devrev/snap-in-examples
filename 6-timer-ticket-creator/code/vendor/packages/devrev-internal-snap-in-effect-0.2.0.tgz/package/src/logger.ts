import { Logger } from "effect";

// One JSON object per line so the stdout the DevRev runtime captures is queryable, not free-text.
const jsonLogger = Logger.make(({ logLevel, message, date, annotations }) => {
  const parts = Array.isArray(message) ? message : [message];
  const record: Record<string, unknown> = {
    ts: date.toISOString(),
    level: logLevel.label,
    msg: parts.map((p) => (typeof p === "string" ? p : String(p))).join(" "),
  };
  for (const [key, value] of annotations as Iterable<[string, unknown]>) {
    record[key] = value;
  }
  // oxlint-disable-next-line effecttsgo/global-console -- Final structured-log output sink.
  console.log(JSON.stringify(record));
});

export const LoggerLive = Logger.replace(Logger.defaultLogger, jsonLogger);
