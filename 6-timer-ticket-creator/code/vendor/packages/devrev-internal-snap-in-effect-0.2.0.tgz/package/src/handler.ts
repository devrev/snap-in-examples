import {
  Error_Type,
  FunctionExecutionError,
  type OperationOutput,
} from "@devrev/typescript-sdk/dist/snap-ins";
import { Cause, Effect, Exit, Layer, Option, Schema } from "effect";
import { DevRev, layerFromEvents, type SdkFactories } from "./devrev-client";
import { decodeConfig } from "./config";
import { ConfigError, InvalidEvent, MissingContext, renderFailure, renderMessage } from "./errors";
import {
  decodeEvent,
  logAnnotations,
  type CredentialSource,
  type SnapInEvent,
} from "./event";
import { LoggerLive } from "./logger";

export type Handler<Out> = (events: readonly unknown[]) => Promise<Out>;

type ProgramWithConfig<A, Out, E, Services = never> = (
  event: SnapInEvent,
  config: A,
) => Effect.Effect<Out, E, DevRev | Services>;
type ProgramNoConfig<Out, E, Services = never> = (
  event: SnapInEvent,
) => Effect.Effect<Out, E, DevRev | Services>;

export type FailureInfo = {
  readonly archetype: string;
  readonly event: unknown;
  readonly message: string;
  readonly cause: Cause.Cause<unknown>;
};

/** Best-effort observation, never a replacement for platform retry or dead-letter handling. */
export type FailureSink<Services = never> = (
  info: FailureInfo,
) => Effect.Effect<void, unknown, DevRev | Services>;

type BaseHandlerOptions = {
  readonly sdk?: SdkFactories;
  /** Overall invocation budget. Default 110s; set below the deployed Lambda timeout. */
  readonly timeoutMs?: number;
};

export type DependencyLayer<Services> = Layer.Layer<Services, unknown, DevRev>;

type ProvidedDependencies<Services> = {
  /** Built once per invocation after DevRev, which is available to the Layer. */
  readonly dependencies: DependencyLayer<Services>;
};

export type HandlerOptions = BaseHandlerOptions & {
  readonly dependencies?: never;
  readonly onFailure?: never;
};

export type HandlerOptionsWithDependencies<Services> = BaseHandlerOptions &
  ProvidedDependencies<Services> & {
    readonly onFailure?: never;
  };

export type AutomationHandlerOptions = BaseHandlerOptions & {
  readonly dependencies?: never;
  /** Observes event failures after SDK setup, for at most one second. */
  readonly onFailure?: FailureSink;
};

export type AutomationHandlerOptionsWithDependencies<Services> =
  BaseHandlerOptions &
  ProvidedDependencies<Services> & {
    /** Observes event failures after SDK setup, for at most one second. */
    readonly onFailure?: FailureSink<Services>;
  };

export type AutomationAdapterOptions<A, I> = AutomationHandlerOptions & {
  readonly config: Schema.Schema<A, I>;
};

export type AutomationAdapterOptionsWithDependencies<A, I, Services> =
  AutomationHandlerOptionsWithDependencies<Services> & {
    readonly config: Schema.Schema<A, I>;
  };

export type AdapterOptions<A, I> = HandlerOptions & {
  readonly config: Schema.Schema<A, I>;
};

export type AdapterOptionsWithDependencies<A, I, Services> =
  HandlerOptionsWithDependencies<Services> & {
    readonly config: Schema.Schema<A, I>;
  };

type NoConfigOptions = HandlerOptions & {
  readonly config?: never;
};

type NoConfigOptionsWithDependencies<Services> =
  HandlerOptionsWithDependencies<Services> & {
    readonly config?: never;
  };

type ErasedProgram = (
  event: SnapInEvent,
  config: unknown,
) => Effect.Effect<unknown, unknown, never>;

type ErasedOptions = BaseHandlerOptions & {
  readonly onFailure?: (info: FailureInfo) => Effect.Effect<void, unknown, never>;
  readonly config?: Schema.Schema<unknown, unknown>;
  readonly dependencies?: Layer.Layer<never, unknown, DevRev>;
};

type Normalized = ErasedOptions & {
  readonly credentialSource: CredentialSource;
  readonly program: ErasedProgram;
};

const normalize = (
  a: unknown,
  b: unknown,
  credentialSource: CredentialSource = "service_account_token",
): Normalized => {
  if (typeof a === "function") {
    // Public overloads prove that the invocation Layer satisfies the program.
    const program = a as unknown as ErasedProgram;
    return { credentialSource, program };
  }
  // Public overloads enforce service/config relationships; erase them only at this boundary.
  const opts = a as ErasedOptions;
  if (opts.timeoutMs !== undefined && (!Number.isFinite(opts.timeoutMs) || opts.timeoutMs <= 0)) {
    throw new RangeError("timeoutMs must be a positive finite number");
  }
  const program = b as ErasedProgram;
  return { ...opts, credentialSource, program };
};

const runOne = (raw: unknown, n: Normalized): Effect.Effect<unknown, unknown, never> =>
  Effect.gen(function* () {
    const event = yield* decodeEvent(raw, n.credentialSource);
    if (!event.token?.trim()) return yield* new MissingContext({ field: `context.secrets.${n.credentialSource}` });
    if (!event.endpoint) return yield* new MissingContext({ field: "execution_metadata.devrev_endpoint" });
    const config = n.config ? yield* decodeConfig(n.config, event) : undefined;
    return yield* n.program(event, config);
  }).pipe(Effect.annotateLogs(logAnnotations(raw)));

const invocationLayer = (
  events: readonly unknown[],
  n: Normalized,
): Layer.Layer<DevRev, unknown> => {
  const devrev = layerFromEvents(events, n.sdk, n.credentialSource);
  return n.dependencies === undefined
    ? devrev
    : Layer.provideMerge(n.dependencies, devrev);
};

const observeFailure = (raw: unknown, cause: Cause.Cause<unknown>, n: Normalized) =>
  Effect.gen(function* () {
    yield* Effect.logError(`automation failed: ${renderFailure(cause)}`);
    if (!n.onFailure) return;
    // Suspend construction too: a synchronously throwing observer must not replace the original error.
    const observer = n.onFailure;
    yield* Effect.suspend(() => observer({
      archetype: "automation", event: raw, message: renderMessage(cause), cause,
    })).pipe(
      Effect.timeout("1 second"),
      Effect.catchAllCause((observerCause) =>
        Effect.logError(`automation onFailure observer failed: ${renderFailure(observerCause)}`)),
    );
  }).pipe(Effect.annotateLogs(logAnnotations(raw)));

const runBatch = (events: readonly unknown[], n: Normalized, observe: boolean) =>
  Effect.scoped(Effect.gen(function* () {
    if (events.length === 0) return undefined;
    const context = yield* Layer.build(invocationLayer(events, n));
    let firstFailure: Cause.Cause<unknown> | undefined;
    let last: unknown;
    for (const raw of events) {
      const exit = yield* Effect.exit(Effect.provide(runOne(raw, n), context));
      if (Exit.isFailure(exit)) {
        firstFailure ??= exit.cause;
        if (observe) yield* Effect.provide(observeFailure(raw, exit.cause, n), context);
      } else {
        last = exit.value;
      }
    }
    if (firstFailure) return yield* Effect.failCause(firstFailure);
    return last;
  }));

const runSingle = (events: readonly unknown[], n: Normalized) =>
  Effect.scoped(Effect.gen(function* () {
    if (events.length !== 1) return yield* new InvalidEvent({ message: "Expected exactly one event" });
    const context = yield* Layer.build(invocationLayer(events, n));
    return yield* Effect.provide(runOne(events[0], n), context);
  }));

const retryDecision = (cause: Cause.Cause<unknown>): boolean => {
  // Cancellation can follow a committed write; replay is not implied by interruption.
  if (Cause.isInterruptedOnly(cause)) return false;
  const failure = Cause.failureOption(cause);
  const value = Option.isSome(failure) ? failure.value : Option.getOrUndefined(Cause.dieOption(cause));
  try {
    if (typeof value === "object" && value !== null && "retry" in value && typeof value.retry === "boolean") {
      return value.retry;
    }
    if (value instanceof InvalidEvent || value instanceof ConfigError || value instanceof MissingContext) return false;
  } catch {
    // A hostile getter/proxy in an error must not replace the original reported failure.
    return false;
  }
  // Match the runner's default for unclassified errors; authors can explicitly set retry=false.
  return true;
};

const executeExit = <A>(
  program: Effect.Effect<A, unknown>,
  events: readonly unknown[],
  n: Normalized,
  archetype: string,
): Promise<Exit.Exit<A, unknown>> =>
  Effect.runPromiseExit(program.pipe(
    Effect.timeoutFail({
      duration: n.timeoutMs ?? 110_000,
      // An interrupted invocation may already have committed a write. Automatic replay is unsafe.
      onTimeout: () => new FunctionExecutionError("Snap-in execution deadline exceeded", false),
    }),
    Effect.tapErrorCause((cause) => Effect.logError(`${archetype} invocation failed: ${renderFailure(cause)}`)),
    Effect.annotateLogs(logAnnotations(events[0])),
    Effect.provide(LoggerLive),
  ));

const execute = async <A>(
  program: Effect.Effect<A, unknown>,
  events: readonly unknown[],
  n: Normalized,
  archetype: string,
): Promise<A> => {
  const exit = await executeExit(program, events, n, archetype);
  if (Exit.isFailure(exit)) {
    // runPromise would wrap the error in FiberFailure and lose the runner's structural .retry flag.
    throw new FunctionExecutionError(renderMessage(exit.cause), retryDecision(exit.cause));
  }
  return exit.value;
};

/**
 * Automation: ignore successful return values, but reject on failure so DevRev can record/retry it.
 * Events run sequentially. A manually supplied batch continues then rejects with its first failure;
 * replay may repeat completed events. The platform currently invokes handlers with one event.
 * onFailure observes event failures only; missing invocation context rejects directly to the runner.
 */
export function automation<A, I, Services, E>(
  opts: AutomationAdapterOptionsWithDependencies<A, I, Services>,
  program: ProgramWithConfig<A, unknown, E, Services>,
): Handler<void>;
export function automation<A, I, E>(
  opts: AutomationAdapterOptions<A, I>,
  program: ProgramWithConfig<A, unknown, E>,
): Handler<void>;
export function automation<Services, E>(
  opts: AutomationHandlerOptionsWithDependencies<Services> & {
    readonly config?: never;
  },
  program: ProgramNoConfig<unknown, E, Services>,
): Handler<void>;
export function automation<E>(
  opts: AutomationHandlerOptions & { readonly config?: never },
  program: ProgramNoConfig<unknown, E>,
): Handler<void>;
export function automation<E>(program: ProgramNoConfig<unknown, E>): Handler<void>;
export function automation(a: unknown, b?: unknown): Handler<void> {
  const n = normalize(a, b);
  return async (events) => { await execute(runBatch(events, n, true), events, n, "automation"); };
}

/** Synchronous return adapter. Errors reject with their retry flag intact.
 * @experimental Command activation remains blocked by the platform RPC.
 */
export function command<A, I, Out, Services, E>(
  opts: AdapterOptionsWithDependencies<A, I, Services>,
  program: ProgramWithConfig<A, Out, E, Services>,
): Handler<Out | undefined>;
export function command<A, I, Out, E>(
  opts: AdapterOptions<A, I>,
  program: ProgramWithConfig<A, Out, E>,
): Handler<Out | undefined>;
export function command<Out, Services, E>(
  opts: NoConfigOptionsWithDependencies<Services>,
  program: ProgramNoConfig<Out, E, Services>,
): Handler<Out | undefined>;
export function command<Out, E>(
  opts: NoConfigOptions,
  program: ProgramNoConfig<Out, E>,
): Handler<Out | undefined>;
export function command<Out, E>(program: ProgramNoConfig<Out, E>): Handler<Out | undefined>;
export function command(a: unknown, b?: unknown): Handler<unknown> {
  const n = normalize(a, b);
  return (events) => execute(runBatch(events, n, false), events, n, "command");
}

export type WebhookResponse = {
  readonly status_code: number;
  readonly headers?: Record<string, string>;
  readonly body?: string;
};

/** Ingress: one request, with a generic HTTP 500 on failure. Error details stay in logs. */
export function ingress<A, I, Services, E>(
  opts: AdapterOptionsWithDependencies<A, I, Services>,
  program: ProgramWithConfig<A, WebhookResponse, E, Services>,
): Handler<WebhookResponse>;
export function ingress<A, I, E>(
  opts: AdapterOptions<A, I>,
  program: ProgramWithConfig<A, WebhookResponse, E>,
): Handler<WebhookResponse>;
export function ingress<Services, E>(
  opts: NoConfigOptionsWithDependencies<Services>,
  program: ProgramNoConfig<WebhookResponse, E, Services>,
): Handler<WebhookResponse>;
export function ingress<E>(
  opts: NoConfigOptions,
  program: ProgramNoConfig<WebhookResponse, E>,
): Handler<WebhookResponse>;
export function ingress<E>(program: ProgramNoConfig<WebhookResponse, E>): Handler<WebhookResponse>;
export function ingress(a: unknown, b?: unknown): Handler<WebhookResponse> {
  const n = normalize(a, b);
  return async (events) => {
    try {
      return await execute(runSingle(events, n), events, n, "ingress") as WebhookResponse;
    } catch {
      return { status_code: 500, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ error: "Internal server error" }) };
    }
  };
}

/** Lifecycle hook: reject with a clean message so the platform marks the lifecycle step failed. */
export function lifecycleHook<A, I, Out, Services, E>(
  opts: AdapterOptionsWithDependencies<A, I, Services>,
  program: ProgramWithConfig<A, Out, E, Services>,
): Handler<Out>;
export function lifecycleHook<A, I, Out, E>(
  opts: AdapterOptions<A, I>,
  program: ProgramWithConfig<A, Out, E>,
): Handler<Out>;
export function lifecycleHook<Out, Services, E>(
  opts: NoConfigOptionsWithDependencies<Services>,
  program: ProgramNoConfig<Out, E, Services>,
): Handler<Out>;
export function lifecycleHook<Out, E>(
  opts: NoConfigOptions,
  program: ProgramNoConfig<Out, E>,
): Handler<Out>;
export function lifecycleHook<Out, E>(program: ProgramNoConfig<Out, E>): Handler<Out>;
export function lifecycleHook(a: unknown, b?: unknown): Handler<unknown> {
  const n = normalize(a, b);
  return (events) => execute(runSingle(events, n), events, n, "lifecycle_hook");
}

/** Operation: one invocation principal, one event, and one protobuf-compatible SDK output. */
export function operation<A, I, Services, E>(
  opts: AdapterOptionsWithDependencies<A, I, Services>,
  program: ProgramWithConfig<A, OperationOutput, E, Services>,
): Handler<OperationOutput>;
export function operation<A, I, E>(
  opts: AdapterOptions<A, I>,
  program: ProgramWithConfig<A, OperationOutput, E>,
): Handler<OperationOutput>;
export function operation<Services, E>(
  opts: NoConfigOptionsWithDependencies<Services>,
  program: ProgramNoConfig<OperationOutput, E, Services>,
): Handler<OperationOutput>;
export function operation<E>(
  opts: NoConfigOptions,
  program: ProgramNoConfig<OperationOutput, E>,
): Handler<OperationOutput>;
export function operation<E>(program: ProgramNoConfig<OperationOutput, E>): Handler<OperationOutput>;
export function operation(a: unknown, b?: unknown): Handler<OperationOutput> {
  const n = normalize(a, b, "access_token");
  return async (events) => {
    const exit = await executeExit(runSingle(events, n), events, n, "operation");
    if (Exit.isFailure(exit)) {
      return {
        error: {
          message: renderMessage(exit.cause),
          type: retryDecision(exit.cause) ? Error_Type.RetryExecution : Error_Type.InvalidRequest,
        },
        output: undefined,
        port_outputs: [],
      };
    }
    return exit.value as OperationOutput;
  };
}

/** Generic batch synchronous adapter alias. */
export const syncFunction = command;
