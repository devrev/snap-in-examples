import { Effect, Schema } from "effect";
import { ArrayFormatter } from "effect/ParseResult";
import { InvalidEvent } from "./errors";
import { SnapInEvent } from "./event";

// Schemas are intentionally partial and open (excess properties ignored) so they stay valid as DevRev adds fields.
export const Work = Schema.Struct({
  id: Schema.String,
  display_id: Schema.optional(Schema.String),
  type: Schema.String,
  title: Schema.optional(Schema.String),
  severity: Schema.optional(Schema.String),
  priority: Schema.optional(Schema.String),
});
export type Work = Schema.Schema.Type<typeof Work>;

export const WorkCreated = Schema.Struct({
  type: Schema.optional(Schema.String),
  work_created: Schema.Struct({ work: Work }),
});
export type WorkCreated = Schema.Schema.Type<typeof WorkCreated>;

export const WorkUpdated = Schema.Struct({
  type: Schema.optional(Schema.String),
  work_updated: Schema.Struct({
    work: Work,
    old_work: Schema.optional(Work),
  }),
});
export type WorkUpdated = Schema.Schema.Type<typeof WorkUpdated>;

// The invoked-on object is exposed under different keys per surface, so all are optional; use `commandObjectId`.
export const CommandPayload = Schema.Struct({
  source_id: Schema.optional(Schema.String),
  id: Schema.optional(Schema.String),
  object_id: Schema.optional(Schema.String),
  parameters: Schema.optional(Schema.String),
  actor_id: Schema.optional(Schema.String),
});
export type CommandPayload = Schema.Schema.Type<typeof CommandPayload>;

export const commandObjectId = (p: CommandPayload): string | undefined =>
  p.source_id ?? p.id ?? p.object_id;

export const decodePayload = <A, I>(
  schema: Schema.Schema<A, I>,
  event: SnapInEvent,
): Effect.Effect<A, InvalidEvent> =>
  Schema.decodeUnknown(schema)(event.payload).pipe(
    Effect.mapError(
      (e) =>
        new InvalidEvent({
          message: ArrayFormatter.formatErrorSync(e)
            .map((i) => `${i.path.join(".") || "(root)"}: ${i.message}`)
            .join("; "),
        }),
    ),
  );
