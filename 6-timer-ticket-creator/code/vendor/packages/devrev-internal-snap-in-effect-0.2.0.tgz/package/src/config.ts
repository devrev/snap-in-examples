import { Effect, Schema } from "effect";
import { ArrayFormatter } from "effect/ParseResult";
import { ConfigError } from "./errors";
import { SnapInEvent } from "./event";

// A global_values scalar can arrive typed (YAML default) or stringified (form value); these coerce both.
export const CoercedBoolean = Schema.transform(
  Schema.Union(Schema.Boolean, Schema.Literal("true"), Schema.Literal("false")),
  Schema.Boolean,
  {
    strict: true,
    decode: (v) => (typeof v === "boolean" ? v : v === "true"),
    encode: (b) => b,
  },
);

export const CoercedNumber = Schema.Union(
  Schema.Number,
  Schema.NumberFromString,
);

export const decodeConfig = <A, I>(
  schema: Schema.Schema<A, I>,
  event: SnapInEvent,
): Effect.Effect<A, ConfigError> =>
  Schema.decodeUnknown(schema)(event.globalValues as unknown).pipe(
    Effect.mapError(
      (e) =>
        new ConfigError({
          message: ArrayFormatter.formatErrorSync(e)
            .map((i) => `${i.path.join(".") || "(root)"}: ${i.message}`)
            .join("; "),
        }),
    ),
  );
