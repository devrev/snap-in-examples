import { type betaSDK } from "@devrev/typescript-sdk";
import { Context, Effect, Layer } from "effect";
import { DevRev, devRevHttpStatus, type DevRevService } from "./devrev-client";
import type { DevRevApiError } from "./errors";

export type TenantCustomObject = betaSDK.CustomObject;

export type TenantCustomObjectFieldKey = `tnt__${string}`;

export type TenantCustomObjectFields = Readonly<Record<TenantCustomObjectFieldKey, unknown>>;

export type TenantCustomObjectCreateOnceResult =
  | { readonly _tag: "Created"; readonly customObject: TenantCustomObject }
  | { readonly _tag: "AlreadyExists" };

export type TenantCustomObjectCreateOnceInput = {
  readonly leafType: string;
  readonly uniqueKey: string;
  readonly title?: string;
  readonly customFields?: TenantCustomObjectFields;
  readonly validateRequiredFields?: boolean;
};

export type TenantCustomObjectStoreService = {
  readonly createOnce: (
    input: TenantCustomObjectCreateOnceInput,
  ) => Effect.Effect<TenantCustomObjectCreateOnceResult, DevRevApiError>;
};

export type TenantCustomObjectStoreDependencies = {
  readonly devrev: DevRevService;
};

const makeCreateOnce = (
  devrev: DevRevService,
): TenantCustomObjectStoreService["createOnce"] =>
  (input) =>
    devrev.callBeta(
      "customObjectsCreate",
      (sdk, params) =>
        sdk.customObjectsCreate(
          {
            leaf_type: input.leafType,
            unique_key: input.uniqueKey,
            ...(input.title === undefined ? {} : { title: input.title }),
            custom_schema_spec: {
              tenant_fragment: true,
              validate_required_fields: input.validateRequiredFields ?? true,
            },
            ...(input.customFields === undefined
              ? {}
              : { custom_fields: input.customFields }),
          },
          params,
        ),
      { retry: "transient" },
    ).pipe(
      Effect.map((response) => ({
        _tag: "Created" as const,
        customObject: response.data.custom_object,
      })),
      Effect.catchTag("DevRevApiError", (error) => {
        const status = devRevHttpStatus(error.cause);
        return status === 409
          ? Effect.succeed({ _tag: "AlreadyExists" as const })
          : Effect.fail(error);
      }),
    );

export const makeTenantCustomObjectStore = (
  dependencies: TenantCustomObjectStoreDependencies,
): TenantCustomObjectStoreService => ({
  createOnce: makeCreateOnce(dependencies.devrev),
});

export class TenantCustomObjectStore extends Context.Tag(
  "snap-in/TenantCustomObjectStore",
)<TenantCustomObjectStore, TenantCustomObjectStoreService>() {
  static readonly Live = Layer.effect(
    TenantCustomObjectStore,
    Effect.map(DevRev, (devrev) => makeTenantCustomObjectStore({ devrev })),
  );
}
