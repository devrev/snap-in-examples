import { client, publicSDK } from "@devrev/typescript-sdk";
import { Context, Duration, Effect, Either, Layer, Schedule } from "effect";
import { DevRevApiError, InvalidEvent, MissingContext } from "./errors";
import { decodeEvent, type CredentialSource } from "./event";
import type { Work } from "./payload";

export type PublicSDK = ReturnType<typeof client.setup>;
export type BetaSDK = ReturnType<typeof client.setupBeta>;

export type AsyncMethodName<SDK> = {
  [Key in keyof SDK]-?: NonNullable<SDK[Key]> extends (
    ...args: infer _Args
  ) => PromiseLike<unknown>
    ? Key
    : never;
}[keyof SDK] & string;

export interface SdkFactories {
  readonly setup: (args: { endpoint: string; token: string }) => PublicSDK;
  readonly setupBeta: (args: { endpoint: string; token: string }) => BetaSDK;
}

const defaultFactories: SdkFactories = {
  setup: (args) => client.setup(args),
  setupBeta: (args) => client.setupBeta(args),
};

export type RetryPolicy = "never" | "transient";

export interface CallOptions {
  /** Generic calls do not retry unless this is explicitly set to `"transient"`. */
  readonly retry?: RetryPolicy;
  /** Maximum duration of one SDK attempt. Defaults to 10 seconds. */
  readonly attemptTimeoutMs?: number;
  /** Maximum duration of the complete call, including retry delays. Defaults to 30 seconds. */
  readonly timeoutMs?: number;
}

export type TimelineVisibility = `${publicSDK.TimelineEntryVisibility}`;
export const TimelineVisibility = {
  External: "external",
  Internal: "internal",
  Private: "private",
  Public: "public",
} as const satisfies Record<string, TimelineVisibility>;

export type TimelineBodyType = "data" | "text";
export const TimelineBodyType = {
  Data: "data",
  Text: "text",
} as const satisfies Record<string, TimelineBodyType>;

interface PostCommentBase {
  readonly object: string;
  readonly body: string;
  /** Required because the platform default is external visibility. */
  readonly bodyType?: TimelineBodyType;
  readonly artifacts?: ReadonlyArray<string>;
}

export type PostCommentInput = PostCommentBase & (
  | {
      readonly visibility: "private";
      readonly privateTo?: ReadonlyArray<string>;
    }
  | {
      readonly visibility: Exclude<TimelineVisibility, "private">;
      readonly privateTo?: never;
    }
);

export type DevRevRequestParams = publicSDK.RequestParams & {
  readonly signal: AbortSignal;
  readonly timeout: number;
};

/**
 * The DevRev SDK, packaged as bounded, interruptible effects.
 *
 * One SDK instance is built per invocation after every usable event context has been
 * checked for consistency. `call` is the safe extension point: its callback must pass the
 * supplied `requestParams` as the generated method's second argument. A callback that
 * discards those parameters, or direct use of `public` / `beta()`, is outside the timeout
 * and cancellation guarantees.
 */
export interface DevRevService {
  readonly call: <Operation extends AsyncMethodName<PublicSDK>, A>(
    operation: Operation,
    callback: (
      sdk: Pick<PublicSDK, NoInfer<Operation>>,
      requestParams: DevRevRequestParams,
    ) => Promise<A>,
    options?: CallOptions,
  ) => Effect.Effect<A, DevRevApiError>;
  readonly callBeta: <Operation extends AsyncMethodName<BetaSDK>, A>(
    operation: Operation,
    callback: (
      sdk: Pick<BetaSDK, NoInfer<Operation>>,
      requestParams: DevRevRequestParams,
    ) => Promise<A>,
    options?: CallOptions,
  ) => Effect.Effect<A, DevRevApiError>;
  readonly postComment: (
    input: PostCommentInput,
    options?: CallOptions,
  ) => Effect.Effect<publicSDK.TimelineEntry, DevRevApiError>;
  /** SDK response typing only; decode fields your program relies on. */
  readonly worksGet: (
    id: string,
    options?: CallOptions,
  ) => Effect.Effect<Work, DevRevApiError>;
}

export class DevRev extends Context.Tag("snap-in/DevRev")<
  DevRev,
  DevRevService
>() {}

const DEFAULT_ATTEMPT_TIMEOUT_MS = 10_000;
const DEFAULT_TIMEOUT_MS = 30_000;
const MAX_RETRIES = 3;

const retryPolicy = Schedule.exponential(Duration.millis(500)).pipe(
  Schedule.jittered,
  Schedule.intersect(Schedule.recurs(MAX_RETRIES)),
);

const NETWORK_ERROR_CODES = new Set([
  "ECONNRESET",
  "ECONNREFUSED",
  "EPIPE",
  "ETIMEDOUT",
  "ENOTFOUND",
  "EAI_AGAIN",
  "ECONNABORTED",
  "ERR_NETWORK",
]);

const propertyOf = (value: unknown, key: string): unknown => {
  if (
    (typeof value !== "object" || value === null) &&
    typeof value !== "function"
  ) {
    return undefined;
  }
  try {
    return Reflect.get(value, key);
  } catch {
    return undefined;
  }
};

export const devRevHttpStatus = (cause: unknown): number | undefined => {
  const response = propertyOf(cause, "response");
  const status = propertyOf(response, "status") ?? propertyOf(cause, "status");
  return typeof status === "number" && Number.isFinite(status)
    ? status
    : undefined;
};

/** Classifies only failures whose request is safe to retry at the transport level. */
export const isTransientDevRevFailure = (cause: unknown): boolean => {
  const name = propertyOf(cause, "name");
  const code = propertyOf(cause, "code");
  if (name === "AbortError" || code === "ERR_CANCELED") return false;

  const status = devRevHttpStatus(cause);
  if (status !== undefined) {
    return status === 408 || status === 429 || (status >= 500 && status <= 599);
  }
  return typeof code === "string" && NETWORK_ERROR_CODES.has(code);
};

// oxlint-disable-next-line effecttsgo/extends-native-error -- Internal transport cause is always wrapped in tagged DevRevApiError.
class RequestTimeoutError extends Error {
  readonly code = "ETIMEDOUT";

  constructor(scope: "attempt" | "overall", timeoutMs: number) {
    super(`DevRev SDK ${scope} timed out after ${timeoutMs}ms`);
    this.name = "RequestTimeoutError";
  }
}

interface ResolvedCallOptions {
  readonly retry: RetryPolicy;
  readonly attemptTimeoutMs: number;
  readonly timeoutMs: number;
}

const positiveFinite = (
  value: unknown,
  fallback: number,
  name: string,
): number => {
  const resolved = value === undefined ? fallback : value;
  if (
    typeof resolved !== "number" ||
    !Number.isFinite(resolved) ||
    resolved <= 0
  ) {
    throw new RangeError(`${name} must be a positive finite number`);
  }
  return resolved;
};

const resolveOptions = (
  options: CallOptions | undefined,
  defaultRetry: RetryPolicy,
): ResolvedCallOptions => {
  if (
    options !== undefined &&
    (typeof options !== "object" || options === null || Array.isArray(options))
  ) {
    throw new TypeError("call options must be an object");
  }
  const retry = options?.retry ?? defaultRetry;
  if (retry !== "never" && retry !== "transient") {
    throw new TypeError("retry must be 'never' or 'transient'");
  }
  return {
    retry,
    attemptTimeoutMs: positiveFinite(
      options?.attemptTimeoutMs,
      DEFAULT_ATTEMPT_TIMEOUT_MS,
      "attemptTimeoutMs",
    ),
    timeoutMs: positiveFinite(
      options?.timeoutMs,
      DEFAULT_TIMEOUT_MS,
      "timeoutMs",
    ),
  };
};

const makeService = (
  endpoint: string,
  token: string,
  factories: SdkFactories,
): DevRevService => {
  const pub = factories.setup({ endpoint, token });
  let beta: BetaSDK | undefined;
  const getBeta = (): BetaSDK => beta ??= factories.setupBeta({ endpoint, token });

  const invoke = <A, SDK>(
    operation: string,
    sdk: SDK,
    callback: (
      sdk: SDK,
      requestParams: DevRevRequestParams,
    ) => Promise<A>,
    options: CallOptions | undefined,
    defaultRetry: RetryPolicy,
  ): Effect.Effect<A, DevRevApiError> =>
    Effect.suspend(() => {
      let resolved: ResolvedCallOptions;
      try {
        resolved = resolveOptions(options, defaultRetry);
      } catch (cause) {
        return Effect.fail(
          new DevRevApiError({ operation, cause, retry: false }),
        );
      }

      const retrySafe = resolved.retry === "transient";
      const attempt = Effect.tryPromise({
        try: (signal) =>
          callback(sdk, {
            signal,
            timeout: resolved.attemptTimeoutMs,
          }),
        catch: (cause) =>
          new DevRevApiError({
            operation,
            cause,
            retry: retrySafe && isTransientDevRevFailure(cause),
          }),
      }).pipe(
        Effect.timeoutFail({
          duration: Duration.millis(resolved.attemptTimeoutMs),
          onTimeout: () =>
            new DevRevApiError({
              operation,
              cause: new RequestTimeoutError(
                "attempt",
                resolved.attemptTimeoutMs,
              ),
              retry: retrySafe,
            }),
        }),
      );

      const attempted = retrySafe
        ? attempt.pipe(
            Effect.retry({
              schedule: retryPolicy,
              while: (error) => error.retry,
            }),
          )
        : attempt;

      return attempted.pipe(
        Effect.timeoutFail({
          duration: Duration.millis(resolved.timeoutMs),
          onTimeout: () =>
            new DevRevApiError({
              operation,
              cause: new RequestTimeoutError("overall", resolved.timeoutMs),
              retry: retrySafe,
            }),
        }),
      );
    });

  const call: DevRevService["call"] = (operation, callback, options) =>
    invoke(operation, pub, callback, options, "never");
  const callBeta: DevRevService["callBeta"] = (operation, callback, options) =>
    Effect.suspend(() => invoke(operation, getBeta(), callback, options, "never"));

  return {
    call,
    callBeta,
    postComment: (input, options) =>
      invoke(
        "timelineEntriesCreate",
        pub,
        (sdk, requestParams) =>
          sdk.timelineEntriesCreate(
            {
              object: input.object,
              type: publicSDK.TimelineEntriesCreateRequestType.TimelineComment,
              body: input.body,
              visibility: input.visibility as publicSDK.TimelineEntryVisibility,
              ...(input.bodyType === undefined
                ? {}
                : { body_type: input.bodyType as publicSDK.TimelineCommentBodyType }),
              ...(input.privateTo === undefined ? {} : { private_to: [...input.privateTo] }),
              ...(input.artifacts === undefined ? {} : { artifacts: [...input.artifacts] }),
            },
            requestParams,
          ),
        options,
        "never",
      ).pipe(Effect.map((response) => response.data.timeline_entry)),
    worksGet: (id, options) =>
      invoke(
        "worksGet",
        pub,
        (sdk, requestParams) => sdk.worksGet({ id }, requestParams),
        options,
        "transient",
      ).pipe(Effect.map((response) => response.data.work)),
  };
};

interface InvocationContext {
  readonly endpoint: string;
  readonly token: string;
}

/**
 * Builds one invocation-scoped SDK after checking every usable event context. Malformed or
 * context-less events are skipped, but two usable events may not disagree on credentials,
 * endpoint, or any supplied Dev Org ID.
 */
export const layerFromEvents = (
  events: readonly unknown[],
  factories: SdkFactories = defaultFactories,
  tokenSource: CredentialSource = "service_account_token",
): Layer.Layer<DevRev, MissingContext | InvalidEvent> =>
  Layer.effect(
    DevRev,
    Effect.gen(function* () {
      let selected: InvocationContext | undefined;
      let devOrgId: string | undefined;
      let lastError: MissingContext | InvalidEvent = new MissingContext({
        field: `context.secrets.${tokenSource}`,
      });

      for (const raw of events) {
        const decoded = yield* Effect.either(decodeEvent(raw, tokenSource));
        if (Either.isLeft(decoded)) {
          lastError = decoded.left;
          continue;
        }
        const event = decoded.right;
        if (!event.token?.trim()) {
          lastError = new MissingContext({
            field: `context.secrets.${tokenSource}`,
          });
          continue;
        }
        if (!event.endpoint) {
          lastError = new MissingContext({
            field: "execution_metadata.devrev_endpoint",
          });
          continue;
        }

        if (
          selected !== undefined &&
          (event.token !== selected.token || event.endpoint !== selected.endpoint)
        ) {
          return yield* new InvalidEvent({
            message:
              "Usable events in one invocation must have identical token and endpoint context",
          });
        }
        if (
          event.devOrgId !== undefined &&
          devOrgId !== undefined &&
          event.devOrgId !== devOrgId
        ) {
          return yield* new InvalidEvent({
            message:
              "Usable events in one invocation must have an identical Dev Org context when supplied",
          });
        }

        selected ??= { endpoint: event.endpoint, token: event.token };
        devOrgId ??= event.devOrgId;
      }

      if (selected === undefined) return yield* lastError;
      return makeService(selected.endpoint, selected.token, factories);
    }),
  );
