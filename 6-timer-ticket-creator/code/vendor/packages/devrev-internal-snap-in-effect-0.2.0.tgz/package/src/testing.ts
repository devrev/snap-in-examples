/// <reference lib="esnext.disposable" preserve="true" />
/** Offline test helpers. Import from @devrev-internal/snap-in-effect/testing. */
import { client, type publicSDK } from "@devrev/typescript-sdk";
import type { BetaSDK, PublicSDK, SdkFactories } from "./devrev-client";

export interface TestRequest {
  readonly path: string | undefined;
  readonly method: string | undefined;
  readonly body: unknown;
  readonly query: unknown;
  readonly signal: publicSDK.RequestParams["signal"];
}

export interface TestResponse {
  readonly data: unknown;
  readonly status?: number;
}

export interface TestDevRev extends Disposable {
  readonly sdk: SdkFactories;
  readonly requests: readonly TestRequest[];
  respondWith(...responses: TestResponse[]): void;
  verify(): void;
}

export type SdkFactoriesFromClientsInput = {
  readonly publicClient: PublicSDK;
  readonly betaClient?: BetaSDK;
};

/**
 * Reuses exact DevRev SDK client instances as `SdkFactories`.
 *
 * The public client is required because `DevRevService` initializes it eagerly.
 * The beta client is optional; if omitted, any beta call fails lazily with a clear
 * message. This lets runnerless integration tests inject real `client.setup` /
 * `client.setupBeta` instances without wrapping or modifying their methods.
 * Adapter-supplied factory arguments are validation context only: keep the
 * synthetic endpoint aligned with the client, but never copy its real credential
 * into the synthetic event.
 */
export const sdkFactoriesFromClients = (
  input: SdkFactoriesFromClientsInput,
): SdkFactories => {
  const betaFactory = (_args: { endpoint: string; token: string }) => {
    if (input.betaClient === undefined) {
      throw Object.assign(
        new Error(
          "Beta SDK client was requested but no betaClient was supplied to sdkFactoriesFromClients",
        ),
        { retry: false as const },
      );
    }
    return input.betaClient;
  };
  return {
    setup: (_args) => input.publicClient,
    setupBeta: betaFactory,
  };
};

/** Uses the real generated SDK with an offline Axios adapter; no request can reach the network. */
export const createTestSdk = (
  respond: (request: TestRequest) => TestResponse | Promise<TestResponse> = (request) => {
    throw new Error(`Unexpected SDK request in test: ${request.method} ${request.path}`);
  },
): SdkFactories => {
  const configure = <A extends PublicSDK | BetaSDK>(sdk: A): A => {
    sdk.instance.defaults.adapter = async (config) => {
      const response = await respond({
        path: config.url,
        method: config.method,
        body: typeof config.data === "string" ? JSON.parse(config.data) as unknown : config.data,
        query: config.params as unknown,
        signal: config.signal,
      });
      const status = response.status ?? 200;
      if (status < 200 || status >= 300) {
        throw Object.assign(new Error(`Test HTTP ${status}`), { response: { status, data: response.data } });
      }
      return { data: response.data, status, statusText: "Test response", headers: {}, config };
    };
    return sdk;
  };
  return {
    setup: (args) => configure(client.setup(args)),
    setupBeta: (args) => configure(client.setupBeta(args)),
  };
};

/** Creates an isolated ordered-response SDK fixture and verifies all transport activity. */
export const createTestDevRev = (): TestDevRev => {
  const requests: TestRequest[] = [];
  const responses: TestResponse[] = [];
  let unexpectedRequests = 0;

  const sdk = createTestSdk((request) => {
    requests.push(request);
    const response = responses.shift();
    if (response === undefined) {
      unexpectedRequests++;
      throw new Error(`Unexpected SDK request in test: ${request.method} ${request.path}`);
    }
    return response;
  });

  const verify = () => {
    const failures: string[] = [];
    if (unexpectedRequests > 0) {
      failures.push(`${unexpectedRequests} unexpected SDK request(s)`);
    }
    if (responses.length > 0) {
      failures.push(`${responses.length} unused SDK response(s)`);
    }
    if (failures.length > 0) {
      throw new Error(`Test DevRev verification failed: ${failures.join("; ")}`);
    }
  };

  return {
    sdk,
    requests,
    respondWith: (...queued) => {
      responses.push(...queued);
    },
    verify,
    [Symbol.dispose]: verify,
  };
};

export interface TestEventOptions {
  readonly globalValues?: Record<string, unknown>;
  readonly keyrings?: Record<string, unknown>;
  readonly eventType?: string;
  readonly devOrgId?: string;
  readonly attemptNumber?: number;
  readonly functionName?: string;
  readonly requestId?: string;
  readonly endpoint?: string;
  readonly serviceAccountToken?: string;
}

/** Synthetic envelope only; never copy a real service-account token into fixtures. */
export const testEvent = (payload: unknown, options: TestEventOptions = {}) => ({
  payload,
  context: {
    dev_oid: options.devOrgId ?? "devo/test",
    attempt_number: options.attemptNumber ?? null,
    secrets: { service_account_token: options.serviceAccountToken ?? "test-token" },
  },
  execution_metadata: {
    function_name: options.functionName ?? "test_function",
    event_type: options.eventType ?? null,
    request_id: options.requestId ?? "test-request",
    devrev_endpoint: options.endpoint ?? "https://invalid.example",
  },
  input_data: {
    global_values: options.globalValues ?? {},
    keyrings: options.keyrings ?? null,
  },
});

export interface TestOperationEventOptions extends Omit<TestEventOptions, "serviceAccountToken"> {
  readonly accessToken?: string;
}

/** Synthetic operation envelope only; the access token is never a real credential. */
export const testOperationEvent = (
  payload: unknown,
  options: TestOperationEventOptions = {},
) => ({
  payload,
  context: {
    dev_oid: options.devOrgId ?? "devo/test",
    attempt_number: options.attemptNumber ?? null,
    secrets: { access_token: options.accessToken ?? "test-access-token", service_account_token: null },
  },
  execution_metadata: {
    function_name: options.functionName ?? "test_operation",
    event_type: options.eventType ?? null,
    request_id: options.requestId ?? "test-request",
    devrev_endpoint: options.endpoint ?? "https://invalid.example",
  },
  input_data: {
    global_values: options.globalValues ?? {},
    keyrings: options.keyrings ?? null,
  },
});

export interface TestCustomObjectCreatedInput {
  readonly leafType: string;
  readonly customFields: Record<string, unknown>;
  readonly id?: string;
  readonly uniqueKey?: string;
}

export const testCustomObjectCreatedEvent = (
  input: TestCustomObjectCreatedInput,
  options: TestEventOptions = {},
) => testEvent({
  type: "custom_object_created",
  custom_object_created: {
    custom_object: {
      id: input.id ?? "don:core:dvrv-us-1:devo/test:custom_object/1",
      leaf_type: input.leafType,
      custom_fields: input.customFields,
      ...(input.uniqueKey === undefined ? {} : { unique_key: input.uniqueKey }),
    },
  },
}, { ...options, eventType: options.eventType ?? "custom_object_created" });
