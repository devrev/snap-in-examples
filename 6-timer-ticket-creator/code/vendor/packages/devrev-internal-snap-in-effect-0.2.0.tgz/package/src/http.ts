import { Data, Effect, Schema } from "effect";

export type FetchLike = (
  input: string | URL | Request,
  init?: RequestInit,
) => Promise<Response>;

export type HttpRequestInit = Omit<RequestInit, "signal">;

export class HttpTransportError extends Data.TaggedError("HttpTransportError")<{
  readonly cause: unknown;
}> {}

export class HttpResponseDecodeError extends Data.TaggedError("HttpResponseDecodeError")<{
  readonly cause: unknown;
}> {}

export type HttpClientService = {
  readonly execute: (
    input: string | URL | Request,
    init?: HttpRequestInit,
  ) => Effect.Effect<Response, HttpTransportError>;
  readonly decodeJson: <A, I, R>(
    response: Response,
    schema: Schema.Schema<A, I, R>,
  ) => Effect.Effect<A, HttpResponseDecodeError, R>;
};

const decodeJson = <A, I, R>(
  response: Response,
  schema: Schema.Schema<A, I, R>,
): Effect.Effect<A, HttpResponseDecodeError, R> =>
  Effect.tryPromise({
    try: () => response.json() as Promise<unknown>,
    catch: (cause) => new HttpResponseDecodeError({ cause }),
  }).pipe(
    Effect.flatMap((body) =>
      Schema.decodeUnknown(schema)(body).pipe(
        Effect.mapError((cause) => new HttpResponseDecodeError({ cause })),
      ),
    ),
  );

export type HttpClientDependencies = {
  readonly fetch?: FetchLike;
};

/**
 * Wraps a Fetch-compatible transport in interruptible Effects.
 *
 * Status acceptance, retries, authentication, and idempotency are deliberately left to
 * the provider adapter because those policies are not transport concerns.
 */
export const makeHttpClient = (
  dependencies: HttpClientDependencies = {},
): HttpClientService => {
  const fetchImpl = dependencies.fetch ?? fetch;
  return {
    execute: (input, init) =>
      Effect.tryPromise({
        try: (signal) => fetchImpl(input, { ...init, signal }),
        catch: (cause) => new HttpTransportError({ cause }),
      }),
    decodeJson,
  };
};
