import { Cause, Data, Option } from "effect";

const propertyOf = (value: unknown, key: string): unknown => {
  if (
    (typeof value !== "object" || value === null) &&
    typeof value !== "function"
  ) {
    return undefined;
  }
  try {
    return Reflect.get(value, key);
  } catch {
    return undefined;
  }
};

const stringifyUnknown = (value: unknown): string => {
  const seen = new WeakSet<object>();
  try {
    const json = JSON.stringify(value, (_key, current: unknown) => {
      if (typeof current === "bigint") return `${current}n`;
      if (typeof current === "object" && current !== null) {
        if (seen.has(current)) return "[Circular]";
        seen.add(current);
      }
      return current;
    });
    if (typeof json === "string" && json.length > 0) return json;
  } catch {
    // Fall through to String for getters, proxies, and other hostile values.
  }
  try {
    const text = String(value);
    return text.length > 0 ? text : "unknown failure";
  } catch {
    return "unknown failure";
  }
};

const messageOfFailure = (value: unknown): string => {
  const message = propertyOf(value, "message");
  if (typeof message === "string" && message.length > 0) return message;
  const tag = propertyOf(value, "_tag");
  if (typeof tag === "string" && tag.length > 0) return tag;
  return typeof value === "string" && value.length > 0
    ? value
    : stringifyUnknown(value);
};

export class InvalidEvent extends Data.TaggedError("InvalidEvent")<{
  readonly message: string;
}> {}

export class MissingContext extends Data.TaggedError("MissingContext")<{
  readonly field: string;
}> {
  override get message(): string {
    return `Missing required runtime context: ${this.field}`;
  }
}

export class ConfigError extends Data.TaggedError("ConfigError")<{
  readonly message: string;
}> {}

export class DevRevApiError extends Data.TaggedError("DevRevApiError")<{
  readonly operation: string;
  readonly cause: unknown;
  /** Whether both the operation policy and failure classification permit replay. */
  readonly retry: boolean;
}> {
  override get message(): string {
    return `DevRev API call '${this.operation}' failed: ${messageOfFailure(this.cause)}`;
  }
}

export type FrameworkError =
  | InvalidEvent
  | MissingContext
  | ConfigError
  | DevRevApiError;

/** Verbose rendering for logs; defects retain Effect's pretty cause when possible. */
export const renderFailure = (cause: Cause.Cause<unknown>): string => {
  const failure = Cause.failureOption(cause);
  if (Option.isSome(failure)) return messageOfFailure(failure.value);
  try {
    return Cause.pretty(cause);
  } catch {
    const defect = Cause.dieOption(cause);
    return Option.isSome(defect)
      ? stringifyUnknown(defect.value)
      : "internal error";
  }
};

/** Clean one-line rendering for caller-visible failures; defect traces remain log-only. */
export const renderMessage = (cause: Cause.Cause<unknown>): string => {
  const failure = Cause.failureOption(cause);
  if (Option.isSome(failure)) return messageOfFailure(failure.value);
  const defect = Cause.dieOption(cause);
  if (Option.isSome(defect)) {
    const message = propertyOf(defect.value, "message");
    if (typeof message === "string" && message.length > 0) return message;
    if (typeof defect.value === "string" && defect.value.length > 0) {
      return defect.value;
    }
    return "internal error";
  }
  if (Cause.isInterruptedOnly(cause)) return "interrupted";
  return "internal error";
};
