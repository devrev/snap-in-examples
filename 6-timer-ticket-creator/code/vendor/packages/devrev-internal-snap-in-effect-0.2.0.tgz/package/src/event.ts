import { Effect, Schema } from "effect";
import { TreeFormatter } from "effect/ParseResult";
import { InvalidEvent } from "./errors";

// DevRev may send null for optional envelope fields; Schema.optional rejects it.
const optionalNullable = <A, I, R>(schema: Schema.Schema<A, I, R>) =>
  Schema.optionalWith(schema, { nullable: true });

const RawEvent = Schema.Struct({
  payload: Schema.optional(Schema.Unknown),
  context: optionalNullable(
    Schema.Struct({
      dev_oid: optionalNullable(Schema.String),
      attempt_number: optionalNullable(Schema.Int.pipe(Schema.nonNegative())),
      secrets: optionalNullable(
        Schema.Struct({
          service_account_token: optionalNullable(Schema.String),
          access_token: optionalNullable(Schema.String),
        }),
      ),
    }),
  ),
  execution_metadata: optionalNullable(
    Schema.Struct({
      devrev_endpoint: optionalNullable(Schema.String),
      function_name: optionalNullable(Schema.String),
      event_type: optionalNullable(Schema.String),
      request_id: optionalNullable(Schema.String),
    }),
  ),
  input_data: optionalNullable(
    Schema.Struct({
      global_values: optionalNullable(
        Schema.Record({ key: Schema.String, value: Schema.Unknown }),
      ),
      keyrings: optionalNullable(
        Schema.Record({ key: Schema.String, value: Schema.Unknown }),
      ),
    }),
  ),
});

export interface SnapInEvent {
  readonly payload: unknown;
  readonly functionName: string | undefined;
  readonly eventType: string | undefined;
  readonly requestId: string | undefined;
  readonly devOrgId: string | undefined;
  readonly attemptNumber: number | undefined;
  readonly endpoint: string | undefined;
  readonly token: string | undefined;
  readonly globalValues: Record<string, unknown>;
  readonly keyrings: Record<string, unknown>;
}

export type CredentialSource = "service_account_token" | "access_token";

export const decodeEvent = (
  raw: unknown,
  tokenSource: CredentialSource = "service_account_token",
): Effect.Effect<SnapInEvent, InvalidEvent> =>
  Schema.decodeUnknown(RawEvent)(raw).pipe(
    Effect.mapError(
      (e) => new InvalidEvent({ message: TreeFormatter.formatErrorSync(e) }),
    ),
    Effect.map(
      (d): SnapInEvent => ({
        payload: d.payload,
        functionName: d.execution_metadata?.function_name,
        eventType: d.execution_metadata?.event_type,
        requestId: d.execution_metadata?.request_id,
        devOrgId: d.context?.dev_oid,
        attemptNumber: d.context?.attempt_number,
        endpoint: d.execution_metadata?.devrev_endpoint,
        token: d.context?.secrets?.[tokenSource],
        globalValues: (d.input_data?.global_values ?? {}) as Record<
          string,
          unknown
        >,
        keyrings: (d.input_data?.keyrings ?? {}) as Record<string, unknown>,
      }),
    ),
  );

const asString = (value: unknown, fallback: string): string =>
  typeof value === "string" ? value : fallback;

export const logAnnotations = (raw: unknown): Record<string, string> => {
  const meta = (raw as { execution_metadata?: Record<string, unknown> })
    ?.execution_metadata;
  return {
    function_name: asString(meta?.function_name, "unknown"),
    request_id: asString(meta?.request_id, ""),
  };
};
