# @devrev-internal/snap-in-effect

Effect-based adapters and SDK primitives for DevRev snap-ins. Proposed local version
**0.2.0**, unreleased. Manifest authoring lives in the separate
`@devrev-internal/snap-in-manifest` package.
Runtime failures use typed Effect errors; adapter setup rejects invalid options early.
Public APIs document their defaults, result channels, retry behavior, and explicit
escape hatches.

## Handler contract

Programs have the shape `(event, config) => Effect<Output, Error, DevRev>`.
All adapters accept a program alone, `{ sdk, timeoutMs }` plus a program, or
`{ config: MySchema, sdk, timeoutMs }` plus a program receiving decoded config.

| Adapter | Input / success | Failure |
|---|---|---|
| `automation` | Sequential events; returns void | Processes the batch, then rejects its first failure with `retry` preserved |
| `command` / `syncFunction` | Sequential events; returns last value, undefined for empty batch | Rejects with `retry` preserved; command activation remains experimental |
| `operation` | Exactly one event; returns SDK `OperationOutput` | Resolves `OperationOutput.error`; never includes success outputs on failure |
| `lifecycleHook` | Exactly one event; returns program result | Rejects the install/update lifecycle step |
| `ingress` | Exactly one event; returns `WebhookResponse` | Generic JSON HTTP 500; details stay in logs |

`operation` selects `context.secrets.access_token`, the operation execution principal.
It never falls back to `service_account_token`. The other adapters retain their
service-account credential contract. `OperationOutput` is re-exported for consumer
return types; the platform runner handles protobuf serialization.
On Effect failure, `operation` resolves `{ error: { message, type }, output:
undefined, port_outputs: [] }`. A classified `retry: false` becomes `InvalidRequest`;
`retry: true` becomes `RetryExecution`. `RetryExecution` expresses the SDK operation
result classification—it is not a guarantee that the platform will automatically
retry the workflow operation.

The platform runner currently passes one event. Replaying a manually supplied batch
can repeat successful events; the first failed event determines its retry disposition.
`flow-custom-webhook` routed through `automations:` uses **automation**: its return
value does not become the sender's HTTP response.

An explicit boolean `retry` on a failure or defect is preserved. Invalid event,
config, or invocation context is nonretryable. Unknown failures default to retryable,
matching the runner. SDK failures incorporate operation replay safety. Rejecting
adapters throw a real SDK `FunctionExecutionError`, avoiding Effect's FiberFailure
wrapper which otherwise hides the retry flag; `operation` maps the same classification
into its resolved SDK error output.

The invocation deadline defaults to **110 seconds**. Set `timeoutMs` below the actual
Lambda timeout. Expiry interrupts cooperative Effects and is classified nonretryable,
because writes may already have committed. Blocking JavaScript or uninterruptible
work can outlive this budget; this is not a hard process watchdog.

`automation` accepts `onFailure(info)`: a best-effort Effect observer after usable SDK
context exists. It gets the event, cause, and rendered message. It has a one-second
budget; its failure never replaces the original. Missing invocation context and the
overall invocation deadline reject directly. It provides no durable storage or DLQ.

## SDK calls

```ts
import { DevRev, TimelineVisibility } from "@devrev-internal/snap-in-effect";

const devrev = yield* DevRev;
const work = yield* devrev.worksGet(id); // known transient errors may retry

yield* devrev.postComment({
  object: id,
  body,
  visibility: TimelineVisibility.Internal,
}); // one attempt by default

yield* devrev.call("worksGet", (sdk, params) => sdk.worksGet({ id }, params), {
  retry: "transient", // explicitly declare this operation safe to replay
  attemptTimeoutMs: 5_000,
  timeoutMs: 15_000,
});

yield* devrev.callBeta("customObjectsCreate", (sdk, params) =>
  sdk.customObjectsCreate(request, params));
```

`postComment` intentionally models string-body comments (`text` or `data`). Snap Kit and
Snap Widget comments require their structured bodies and should use `call` directly.

`call`, `callBeta`, and `postComment` default to `retry: "never"`; `worksGet` defaults to
`"transient"`. Transient classification covers HTTP 408/429/500–599 and known
transport error codes. Unknown errors without status/code, cancellation, and other
4xx errors do not retry. Retry uses jittered exponential backoff starting at 500 ms,
with at most three retries. The defaults are **10 seconds per attempt / 30 seconds
for the complete call**, including retry delays.

Always forward `params` to the generated SDK method: it includes the abort signal
and request timeout. A callback that discards `params` bypasses transport protections.
Raw SDK access is intentionally not exposed. An abort cannot roll back a request the
server already applied.

These are **per-call** guarantees. A later failure or event redelivery can replay the
whole handler, including an earlier successful write. Persist a stable business key
with a suitable deduplication mechanism when duplicate side effects are unacceptable.
The runtime does not invent a distributed idempotency store.

One SDK is built per invocation. A malformed head event cannot conceal later valid
context, but every event still needs its own credentials and endpoint. Mixed token,
endpoint, or supplied Dev Org IDs reject before the SDK is constructed. No SDK or
credentials are cached across invocations.

## Tenant custom-object persistence

`TenantCustomObjectStore` provides one deliberately narrow persistence primitive:
replay-safe creation under a required `unique_key`. Its live Layer is built from the
invocation-scoped DevRev service.

```ts
import {
  automation,
  TenantCustomObjectStore,
  type SnapInEvent,
} from "@devrev-internal/snap-in-effect";
import { Effect } from "effect";

const program = (_event: SnapInEvent) => Effect.gen(function* () {
  const store = yield* TenantCustomObjectStore;
  return yield* store.createOnce({
    leafType: "webhook_delivery",
    uniqueKey: externalEventId,
    title: `Webhook ${externalEventId}`,
    customFields: { tnt__event_id: externalEventId },
  });
});

const run = automation({ dependencies: TenantCustomObjectStore.Live }, program);
```

The store always selects the tenant fragment, defaults required-field validation to
`true`, retries classified transient failures because the unique-key write is safe to
replay, and maps an HTTP `409` from that create call to `AlreadyExists`. Tenant field
keys must use the `tnt__` prefix. Set `validateRequiredFields: false` only for schemas
that intentionally permit partial or title-only records.

This is not a custom-object database or CRUD repository. It intentionally does not
provide list, update, delete, query, state-machine, retention, or reconciliation policy.
Those operations have domain-specific concurrency and lifecycle semantics and should be
added only with a concrete consumer.

## External HTTP

`makeHttpClient()` turns a Fetch-compatible transport into interruptible Effects and
decodes JSON through an Effect Schema:

```ts
import { makeHttpClient } from "@devrev-internal/snap-in-effect";
import { Effect, Schema } from "effect";

const ResponseBody = Schema.Struct({ id: Schema.String });
const http = makeHttpClient();
// Tests and adapters can inject a transport with makeHttpClient({ fetch: fakeFetch }).

const program = Effect.gen(function* () {
  const response = yield* http.execute("https://provider.example/items");
  if (!response.ok) {
    // Apply the provider's status and retry policy here.
  }
  return yield* http.decodeJson(response, ResponseBody);
});
```

`execute` supplies its own `AbortSignal`, so interruption reaches cooperative Fetch
implementations. It does not classify statuses, retry requests, add authentication,
or invent idempotency behavior; those semantics belong to each provider adapter.

## Decoding and logs

`decodeEvent` normalizes null-tolerant envelopes. `decodePayload(Schema, event)` checks
untrusted payloads; common schemas include `WorkCreated`, `WorkUpdated`, and
`CommandPayload`. `decodeConfig` validates install inputs, with `CoercedBoolean` and
`CoercedNumber` for platform string values.

`SnapInEvent` includes `devOrgId` and optional `attemptNumber` when provided. The
pinned runner does not expose a general event ID; use business payload IDs where
needed. Logs include request/function metadata. Do not log tokens, whole envelopes,
or secrets, and do not treat message text as a stable machine-readable API.

## Testing

There are three levels:

1. **Program-level test** with service `Context.Tag`s and test `Layer`s.
2. **Offline adapter test** with `createTestDevRev`.
3. **Runnerless integration test** with arbitrary real services and, when
   needed, real DevRev clients through `sdkFactoriesFromClients`.

See the workspace [testing guide](../../docs/TESTING.md) for the complete guide, including how to
inject arbitrary external services, what the callable source surfaces simulate, and
the gated live-org read-only example.

### Offline tests

Use the scoped SDK helper with native Bun tests:

```ts
import { createTestDevRev, testEvent } from "@devrev-internal/snap-in-effect/testing";
import { test, expect } from "bun:test";

test("posts the greeting", async () => {
  using devrev = createTestDevRev();
  devrev.respondWith({ data: {} });
  const run = automation({ sdk: devrev.sdk }, program);
  await run([testEvent({ work_created: { work: { id: "TKT-1", type: "ticket" } } })]);
  expect(devrev.requests).toMatchObject([{
    path: "/timeline-entries.create",
    body: { object: "TKT-1", body: "Welcome!" },
  }]);
});
```

Import your actual `program` and its adapter/configuration in the test. Queue one
response per request, in order; use `{ status: 403, data: {} }` for an HTTP failure.
Unexpected requests and unused responses fail scope disposal even when the adapter
converts the failure to a returned error. Queue nothing for a no-call case.
Requests expose `path`, `method`, JSON `body`, SDK `query`, and `signal`.
Always assert the business outcome as well as the number of calls.

`using` runs verification when the test leaves its scope, including on failure.
Each helper owns its state, so there are no global hooks or mock resets to configure.
Use Bun’s `test.each(cases)` for parameterized tests.

`createTestDevRev()` from `/testing` exposes `sdk`,
`requests`, `respondWith(...responses)`, and `verify()`. If your runner/compiler
does not support `using`, call `verify()` in per-test teardown or a `finally` block. `createTestSdk(respond)` remains the
lower-level callback API for specialized delays and network failures. Neither helper
imports a test runner; both use the real generated SDK with an offline Axios adapter.

`testEvent(payload, options?)` creates a synthetic service-account envelope with optional
global values, keyrings, event type, and invocation metadata. `testOperationEvent` supplies
an operation access token. `testCustomObjectCreatedEvent` creates the complete CDC payload.
Pass the raw payload without adding another `payload` wrapper. Response data is
unvalidated fixture data; use independently verified platform shapes.

### Runnerless integration with real services

Arbitrary external services do not need package-specific test APIs. Every service
uses a `Context.Tag`; pass its real or fake implementation to the adapter through
the named `dependencies` Layer:

```ts
import { automation, type SnapInEvent } from "@devrev-internal/snap-in-effect";
import { Context, Effect, Layer } from "effect";

class Helix extends Context.Tag("app/Helix")<Helix, HelixClientService>() {
  static readonly Live = Layer.sync(Helix, () => makeHelixClient());
}

const program = (_event: SnapInEvent) => Effect.gen(function* () {
  const helix = yield* Helix;
  yield* helix.createTicket(ticket);
});

const run = automation({ dependencies: Helix.Live }, program);
```

The adapter builds `dependencies` once per invocation. A Layer may require DevRev;
the adapter supplies its invocation-scoped `DevRev` service before building that
Layer and exposes both contexts to the program.

The DevRev SDK is a special adapter boundary because the runtime builds its
`DevRev` service from the invocation context. For that case,
`sdkFactoriesFromClients({ publicClient, betaClient? })` returns `SdkFactories`
that reuse the exact `client.setup` / `client.setupBeta` instances you supply.
Pass the result to any adapter as `{ sdk: factories }`:

```ts
import { client } from "@devrev/typescript-sdk";
import { sdkFactoriesFromClients, testEvent } from "@devrev-internal/snap-in-effect/testing";
import { automation, DevRev } from "@devrev-internal/snap-in-effect";
import { Effect } from "effect";

const publicClient = client.setup({ endpoint, token });
const run = automation(
  { sdk: sdkFactoriesFromClients({ publicClient }) },
  () => Effect.gen(function* () {
    const service = yield* DevRev;
    const work = yield* service.worksGet(workId);
    return work.id;
  }),
);
await run([testEvent({ work_created: { work: { id: workId, type: "issue" } } }, { endpoint })]);
```

The public client is required because `DevRevService` initializes it eagerly. The
beta client is optional; if a program calls `callBeta` without one, the failure is
lazy and clear. The helper does not wrap or modify client methods; the adapter still
decodes the event, validates mixed-event context, and applies the same timeouts and
retry classification it would with the default factories. Factory arguments from
the synthetic envelope do not reconfigure an injected client: keep its endpoint
aligned with the client, and keep the envelope credential a harmless placeholder.

Run `npm run verify` from the workspace root. See the package
[changelog](CHANGELOG.md) for the unreleased version.

Explicit Effect interruption is nonretryable, just like the invocation deadline:
cancellation does not imply that repeating earlier side effects is safe.
