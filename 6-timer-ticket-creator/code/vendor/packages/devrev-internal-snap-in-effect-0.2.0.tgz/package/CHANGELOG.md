# Changelog

## 0.2.0 — unreleased

- Add automation, lifecycle, operation, ingress, and experimental command adapters.
- Preserve failure disposition; validate invocation context and configuration.
- Bound SDK calls and cooperative handler execution; retry transient reads.
- Provide real-SDK offline testing, synthetic events, and a scoped helper that
  records requests and rejects unexpected calls or unused responses.
- Add bounded `callBeta`, explicit-visibility timeline comments, and complete
  synthetic keyring/custom-object event fixtures.
- Link `call` and `callBeta` operation labels to the generated SDK method exposed
  to their callbacks.
- Add a shared interruptible Fetch transport with Effect Schema JSON decoding.
- Accept injected HTTP dependencies through a named options object and rename the
  internal DevRev SDK module from `client` to `devrev-client` for clarity.
- Add a tenant custom-object `createOnce` store with typed create/conflict outcomes,
  replay-safe transient retries, compile-time `tnt__` field-name enforcement, and a
  DevRev-backed live Layer for the shared service convention.
- Add `sdkFactoriesFromClients({ publicClient, betaClient? })` so runnerless
  integration tests can inject exact real DevRev SDK client instances into any
  existing adapter without wrapping methods or relying on package publication.
- Document the dependency-agnostic three-level testing model: programs with typed
  Context/Layer services, offline adapter tests with `createTestDevRev`, and gated
  runnerless integration tests using arbitrary real services. DevRev's helper is
  explicitly a bridge for the adapter-owned SDK service, not a general DI model.
- Add a named `dependencies` Layer to every adapter so application services and
  invocation-scoped DevRev use one Context/Layer convention. Dependency Layers are
  acquired once per invocation and may themselves require DevRev.
- Add distributable license, explicit CommonJS module type, side-effect metadata, and
  package discovery keywords.

This local candidate changes retry and deadline behavior from the earlier 0.1.0
prototype. No version has been published to the team registry.
