// The Rego policy is the authentication boundary for flow-custom-webhook. This builder
// defines output only after a shared-secret match, so a mismatch produces no event key.

import type { Brand } from "./manifest-values";

/**
 * A Rego policy string produced by this builder (or the {@link rawRegoPolicy} escape).
 *
 * The event-source `policy` field requires this brand. Use {@link rawRegoPolicy} only for
 * reviewed hand-written policies.
 */
export type RegoPolicy = Brand<string, "RegoPolicy">;

/** Quote a value as a Rego string literal. Rego string escaping is JSON's, so this is exact. */
const regoString = (value: string): string => JSON.stringify(value);

/**
 * Reject controls that could become rule separators if a value reaches an unquoted template
 * position. These identifier-like fields do not need controls.
 */
const assertNoControlChars = (name: string, value: string): void => {
  // C0/C1 controls plus Unicode line/paragraph separators.
  // oxlint-disable-next-line eslint/no-control-regex -- rejecting control characters is the security boundary here.
  if (/[\u0000-\u001F\u007F-\u009F\u2028\u2029]/.test(value)) {
    throw new Error(
      `sharedSecretHeaderPolicy: ${name} must not contain control characters or line terminators.`,
    );
  }
};

export interface SharedSecretHeaderPolicyOptions {
  /**
   * The `event_key` emitted on a successful secret match. The bound automation is selected
   * by this key, so it must match the automation's expectation. Must be non-empty.
   */
  readonly eventKey: string;
  /**
   * Header carrying the secret, exactly as it appears in policy input. A 2026-09-07 live
   * proof observed Go-canonical keys and plain string values. A wrong key fails closed;
   * confirm unusual headers against an isolated delivery.
   */
  readonly header: string;
  /**
   * The expected secret value to compare the header against.
   *
   * Author-provided, non-empty value embedded in generated YAML. Load it from protected
   * storage at author time; never hardcode or commit it. Rotate by regenerating and redeploying.
   */
  readonly secret: string;
  /**
   * Key under which the (already-parsed) request body is passed through into the event, AFTER
   * the secret check passes. Defaults to `"body"`, matching the platform's default custom
   * webhook policy. Treat the resulting payload as untrusted input in your handler regardless.
   */
  readonly bodyKey?: string;
}

export interface HmacSha256HeaderPolicyOptions {
  readonly eventKey: string;
  /**
   * Keyring connection name containing the HMAC secret. The event source must declare the
   * same name in its `connections` array so DevRev injects `input.keyrings[name].secret`.
   */
  readonly keyring: string;
  /** Header name exactly as exposed by the webhook policy input (Go-canonical in DevRev). */
  readonly signatureHeader: string;
  /** Defaults to `sha256=`; use an empty string for bare hex signatures. */
  readonly signaturePrefix?: string;
  /** Map of normalized event-payload key to input header name. */
  readonly forwardHeaders?: Readonly<Record<string, string>>;
  /** Success response status. Defaults to 202. */
  readonly successStatus?: number;
}

export interface HmacSha256KeyringWebhookBinding {
  readonly connections: ReadonlyArray<{ readonly name: string }>;
  readonly config: { readonly policy: RegoPolicy };
}

/**
 * Verifies HMAC-SHA256 over the exact base64-encoded `body_raw` supplied by
 * `flow-custom-webhook`, then emits only the parsed body, selected headers, and
 * raw-body SHA-256 fingerprint. Invalid requests fail closed with HTTP 401.
 */
export const hmacSha256HeaderPolicy = (
  options: HmacSha256HeaderPolicyOptions,
): RegoPolicy => {
  for (const [name, value] of [
    ["eventKey", options.eventKey],
    ["keyring", options.keyring],
    ["signatureHeader", options.signatureHeader],
  ] as const) {
    if (value === "") throw new Error(`hmacSha256HeaderPolicy: ${name} must be non-empty.`);
    assertNoControlChars(name, value);
  }
  const prefix = options.signaturePrefix ?? "sha256=";
  assertNoControlChars("signaturePrefix", prefix);
  const successStatus = options.successStatus ?? 202;
  if (!Number.isInteger(successStatus) || successStatus < 200 || successStatus > 299) {
    throw new Error("hmacSha256HeaderPolicy: successStatus must be an integer from 200 through 299.");
  }
  const headerEntries = Object.entries(options.forwardHeaders ?? {})
    .map(([outputName, inputName]) => {
      assertNoControlChars("forwardHeaders key", outputName);
      assertNoControlChars("forwardHeaders value", inputName);
      return `${regoString(outputName)}: input.request.headers[${regoString(inputName)}]`;
    })
    .join(", ");
  const event = `{"body": input.request.body, "headers": {${headerEntries}}, "raw_body_sha256": crypto.sha256(raw_body)}`;
  return `package rego

raw_body := base64.decode(input.request.body_raw)
expected_signature := sprintf(${regoString(`${prefix}%s`)}, [crypto.hmac.sha256(raw_body, input.keyrings[${regoString(options.keyring)}].secret)])

default output = {"response": {"status_code": 401, "body": "Unauthorized"}}

output = {"event": ${event}, "event_key": ${regoString(options.eventKey)}, "response": {"status_code": ${successStatus}}} {
  input.request.method == "POST"
  input.request.headers[${regoString(options.signatureHeader)}] == expected_signature
}
` as RegoPolicy;
};

/**
 * Binds a keyring connection and raw-body HMAC policy as one `flow-custom-webhook` fragment.
 *
 * Returning `connections` and `config.policy` together prevents the common half-configuration
 * where a policy references `input.keyrings` but the event source never requests the connection.
 * Unlike `config.parameters`, the secret value is not embedded in the manifest.
 */
export const hmacSha256KeyringWebhook = (
  options: HmacSha256HeaderPolicyOptions,
): HmacSha256KeyringWebhookBinding => {
  const policy = hmacSha256HeaderPolicy(options);
  return {
    connections: [{ name: options.keyring }],
    config: { policy },
  };
};

/**
 * Build a FAIL-CLOSED shared-secret Rego policy for a `flow-custom-webhook` event source.
 *
 * The generated policy emits `{event, event_key}` ONLY when
 * `input.request.headers[<header>]` equals the expected secret; the request body is passed
 * through into the event ONLY after that check passes. With no matching rule the `output`
 * variable is undefined, so the automation never fires. There is intentionally no
 * pass-through / no-auth / catch-all rule.
 *
 * @example
 * ```ts
 * const policy = sharedSecretHeaderPolicy({
 *   eventKey: "order_received",
 *   header: "X-Devrev-Signature",          // as delivered into the policy input
 *   secret: process.env.WEBHOOK_SECRET!,    // sourced from a secret manager at author time
 * });
 * // event_sources.organization: [{ name, type: "flow-custom-webhook", config: { policy } }]
 * ```
 *
 */
export const sharedSecretHeaderPolicy = (
  opts: SharedSecretHeaderPolicyOptions,
): RegoPolicy => {
  if (opts.eventKey === "") {
    throw new Error("sharedSecretHeaderPolicy: eventKey must be non-empty.");
  }
  if (opts.header === "") {
    throw new Error("sharedSecretHeaderPolicy: header must be non-empty.");
  }
  if (opts.secret === "") {
    // An empty expected value would authorize an empty header.
    throw new Error(
      "sharedSecretHeaderPolicy: secret must be non-empty (an empty expected secret is not fail-closed).",
    );
  }
  assertNoControlChars("eventKey", opts.eventKey);
  assertNoControlChars("header", opts.header);
  const bodyKey = opts.bodyKey ?? "body";
  assertNoControlChars("bodyKey", bodyKey);
  const event = `{${regoString(bodyKey)}: input.request.body}`;
  // No default output: a mismatch must produce no event key.
  const policy = `package rego

# FAIL-CLOSED shared-secret gate for a flow-custom-webhook event source.
# \`output\` is DEFINED ONLY when the request carries the expected secret in the
# configured header; otherwise it is undefined, no event_key is produced, and the
# bound automation never fires. Do NOT add a catch-all default rule.
output = {"event": ${event}, "event_key": ${regoString(opts.eventKey)}} {
  input.request.headers[${regoString(opts.header)}] == ${regoString(opts.secret)}
}
`;
  return policy as RegoPolicy;
};

/**
 * Whole-policy escape hatch: adopt a hand-written Rego policy string as a {@link RegoPolicy}.
 *
 * The caller owns fail-closed behavior; a pass-through policy re-opens the endpoint.
 */
export const rawRegoPolicy = (policy: string): RegoPolicy => policy as RegoPolicy;
