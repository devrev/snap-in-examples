import * as YAML from "yaml";
import type {
  ActAs,
  AdaptableRequestType,
  BuiltInConnectionType,
  CustomConnectionType,
  EventCategory,
  EventType,
  HttpMethod,
  JqQuery,
  KeyringConnectionType,
  KeyringKind,
  OAuthGrantType,
  OperationType,
  Scope,
  TokenInputType,
} from "./manifest-values";
import type { RegoPolicy } from "./rego";
import { and, eventTypeIs, fieldEquals, jqFilter } from "./manifest-values";

// Local manifest-v2 contract snapshot; server validation remains authoritative.

// Keep authoring helpers under `Manifest.*`.
export * from "./manifest-values";
export * from "./rego";

export interface ScopeObject {
  readonly scope: Scope;
  readonly optional?: boolean;
  readonly reason?: string;
}

export interface ActAsScopeObject {
  readonly act_as: ActAs;
  readonly scopes?: ReadonlyArray<ScopeObject>;
}

/** v2 has a single scopes shape: `self` + optional `impersonate` (no flat list). */
export interface Scopes {
  readonly self?: ReadonlyArray<ScopeObject>;
  readonly impersonate?: ReadonlyArray<ActAsScopeObject>;
}

export interface ServiceAccount {
  readonly display_name: string;
  readonly scopes?: Scopes;
}

export interface UiHint {
  readonly display_name?: string;
}

interface InputBase {
  readonly name: string;
  readonly description?: string;
  readonly is_required?: boolean;
  readonly ui?: UiHint;
}

export type ScalarFieldType =
  | "text"
  | "rich_text"
  | "tokens"
  | "bool"
  | "int"
  | "double"
  | "enum"
  | "uenum"
  | "legacy_enum"
  | "id"
  | "timestamp"
  | "date"
  | "composite";

/** Array field types are the scalar names prefixed with `[]`. */
export type ArrayFieldType = `[]${ScalarFieldType}`;

export type Input =
  | (InputBase & {
      readonly field_type: "text" | "rich_text" | "tokens";
      readonly default_value?: string;
    })
  | (InputBase & {
      readonly field_type: "bool";
      readonly default_value?: boolean;
    })
  | (InputBase & {
      readonly field_type: "int" | "double";
      readonly default_value?: number;
    })
  | (InputBase & {
      readonly field_type: "enum" | "uenum" | "legacy_enum";
      readonly allowed_values: ReadonlyArray<string>;
      readonly default_value?: string;
    })
  | (InputBase & {
      readonly field_type: "id";
      readonly id_type?: ReadonlyArray<string>;
      readonly default_value?: string;
    })
  | (InputBase & {
      readonly field_type: "timestamp" | "date";
      readonly default_value?: string;
    })
  | (InputBase & {
      readonly field_type: "composite";
      readonly default_value?: unknown;
    })
  | (InputBase & {
      readonly field_type: ArrayFieldType;
      readonly allowed_values?: ReadonlyArray<string>;
      readonly id_type?: ReadonlyArray<string>;
      readonly default_value?: ReadonlyArray<unknown>;
    });

export interface ScopedInputs {
  readonly organization?: ReadonlyArray<Input>;
  readonly user?: ReadonlyArray<Input>;
}

export interface Keyring {
  readonly name: string;
  readonly description?: string;
  readonly display_name?: string;
  /**
   * Connection types this keyring accepts. Required and must be non-empty — the platform's
   * `validateKeyring` rejects a keyring with zero types. A `[]` still type-checks (an empty
   * array is a valid `ReadonlyArray`), so {@link defineManifest} also min-1-checks it at runtime.
   */
  readonly types: ReadonlyArray<KeyringConnectionType>;
  readonly optional?: boolean;
  readonly allow_multiple?: boolean;
}

export interface ScopedKeyrings {
  readonly organization?: ReadonlyArray<Keyring>;
  readonly user?: ReadonlyArray<Keyring>;
}

export interface DeveloperKeyring {
  readonly name: string;
  readonly description?: string;
  readonly display_name?: string;
}

export interface AdaptableRequestConfig {
  readonly type?: AdaptableRequestType;
  readonly url?: string;
  readonly method?: HttpMethod;
  readonly query_parameters?: Record<string, string>;
  readonly headers?: Record<string, string>;
  readonly body?: string;
  readonly response_jq?: string;
}

export interface ScopeDefinition {
  readonly name: string;
  readonly description: string;
  readonly value: string;
  readonly is_optional?: boolean;
}

export interface TokenField {
  readonly id?: string;
  readonly name?: string;
  readonly description?: string;
  readonly is_optional?: boolean;
  readonly input_type?: TokenInputType;
  readonly include_with_secret?: boolean;
}

export interface Authorize {
  readonly type?: AdaptableRequestType;
  readonly auth_url?: string;
  readonly token_url?: string;
  readonly grant_type?: OAuthGrantType;
  readonly auth_query_parameters?: Record<string, string>;
  readonly token_query_parameters?: Record<string, string>;
  readonly token_headers?: Record<string, string>;
  readonly token_body?: string;
  readonly fields?: ReadonlyArray<TokenField>;
  readonly token_expiry_request?: AdaptableRequestConfig;
  readonly response_jq?: string;
}

export interface SecretConfig {
  readonly secret_transform?: string;
  readonly fields?: ReadonlyArray<TokenField>;
  readonly token_verification?: AdaptableRequestConfig;
  readonly fetch_token?: AdaptableRequestConfig;
}

export interface KeyringType {
  readonly id?: string;
  readonly name?: string;
  readonly description?: string;
  readonly kind?: KeyringKind;
  readonly external_system_name?: string;
  readonly scopes?: ReadonlyArray<ScopeDefinition>;
  readonly scope_delimiter?: string;
  readonly oauth_secret?: string;
  readonly is_subdomain?: boolean;
  readonly domain?: string;
  readonly client_credentials?: AdaptableRequestConfig;
  readonly authorize?: Authorize;
  readonly organization_data?: AdaptableRequestConfig;
  readonly refresh?: AdaptableRequestConfig;
  readonly revoke?: AdaptableRequestConfig;
  readonly secret_config?: SecretConfig;
}

export interface FunctionRuntimeConfig {
  readonly max_retries?: number;
  readonly min_interval?: number;
}

export interface FunctionConfig {
  readonly runtime?: FunctionRuntimeConfig;
}

/**
 * A function declaration. `Fn` is the union of `functionFactory` keys (see
 * {@link defineManifest}); `name` must be one of them, so a declaration can never
 * point at a handler that doesn't exist in code.
 */
export interface FunctionDef<Fn extends string = string> {
  readonly name: Fn;
  readonly description?: string;
  readonly config?: FunctionConfig;
  readonly supports_synchronization?: boolean;
}

export type EventSourceType =
  | "github-webhook"
  | "bitbucket-webhook"
  | "gitlab-webhook"
  | "circleci-webhook"
  | "stripe-webhook"
  | "devrev-events"
  | "devrev-webhook"
  | "flow-events"
  | "timer-events"
  | "track-events"
  | "datadog-monitor-events"
  | "flow-custom-webhook"
  | "betteruptime-incident-webhook"
  | "email-forward"
  | "slack-app-commands"
  | "slack-app-events"
  | "slack-app-interactions"
  | "slack-app-message-actions"
  | "discord-app-interactions";

export interface WorkflowFilter {
  readonly operation_id?: string;
  readonly input_values?: Record<string, unknown>;
}

export interface DevrevWebhookFilter {
  /** Must compile as a JQ filter server-side — build it with the jq helpers or `rawJqFilter`. */
  readonly jq_query?: JqQuery;
  readonly workflow_filters?: ReadonlyArray<WorkflowFilter>;
}

export interface DevrevWebhookConfig {
  readonly event_types: ReadonlyArray<EventType>;
  readonly filter?: DevrevWebhookFilter;
  readonly event_categories?: ReadonlyArray<EventCategory>;
}

export interface TimerEventsConfig {
  /** Only one of `cron` and `interval_seconds` should be set. */
  readonly cron?: string;
  readonly interval_seconds?: number;
  readonly metadata?: Record<string, unknown>;
}

export interface GenericWebhookConfig {
  /**
   * Authentication boundary for `flow-custom-webhook`. Optional in the schema;
   * defineManifest does not require it. Supply a fail-closed policy such as
   * sharedSecretHeaderPolicy and review rawRegoPolicy escapes; pass-through leaves it open.
   */
  readonly policy?: RegoPolicy;
  readonly parameters?: Record<string, unknown>;
}

export interface ConfigTemplate {
  readonly template: string;
  readonly type: "rego";
}

interface AuthConfig {
  readonly name: string;
}

interface EventSourceBase<Fn extends string = string> {
  readonly name: string;
  readonly description?: string;
  readonly display_name?: string;
  readonly connection?: string;
  readonly connections?: ReadonlyArray<AuthConfig>;
  readonly setup_instructions?: string;
  readonly function?: Fn;
  /** Mutually exclusive with `config` (the platform rejects both). */
  readonly config_template?: ConfigTemplate;
}

/** The three types with a structured config; every other type carries a generic config. */
export type EventSource<Fn extends string = string> =
  | (EventSourceBase<Fn> & {
      readonly type: "devrev-webhook";
      readonly config: DevrevWebhookConfig;
    })
  | (EventSourceBase<Fn> & {
      readonly type: "timer-events";
      readonly config: TimerEventsConfig;
    })
  | (EventSourceBase<Fn> & {
      readonly type: "flow-custom-webhook";
      readonly config?: GenericWebhookConfig;
    })
  | (EventSourceBase<Fn> & {
      readonly type: Exclude<
        EventSourceType,
        "devrev-webhook" | "timer-events" | "flow-custom-webhook"
      >;
      readonly config?: Record<string, unknown>;
    });

export interface CustomObjectCreatedSourceOptions {
  readonly name: string;
  readonly leafType: string;
  readonly displayName?: string;
  readonly description?: string;
}

/** Creates a DevRev webhook source filtered to one custom-object leaf type. */
export const customObjectCreatedSource = (
  options: CustomObjectCreatedSourceOptions,
): EventSource<never> => ({
  name: options.name,
  type: "devrev-webhook",
  ...(options.displayName === undefined ? {} : { display_name: options.displayName }),
  ...(options.description === undefined ? {} : { description: options.description }),
  config: {
    event_types: ["custom_object_created"],
    filter: {
      jq_query: jqFilter(and(
        eventTypeIs("custom_object_created"),
        fieldEquals(["custom_object_created", "custom_object", "leaf_type"], options.leafType),
      )),
    },
  },
});

export interface ScopedEventSources<Fn extends string = string> {
  readonly organization?: ReadonlyArray<EventSource<Fn>>;
  readonly user?: ReadonlyArray<EventSource<Fn>>;
}

export interface Automation<Fn extends string = string> {
  readonly name: string;
  readonly description?: string;
  /** Must name an event source declared in `event_sources` (checked by {@link defineManifest}). */
  readonly source: string;
  readonly event_types: ReadonlyArray<EventType>;
  readonly function: Fn;
}

/** The only valid command surface today. */
export type CommandSurfaceName = "discussions";

export type CommandObjectType =
  | "account"
  | "conversation"
  | "engagement"
  | "flow"
  | "issue"
  | "opportunity"
  | "part"
  | "rev_org"
  | "rev_user"
  | "snap_in"
  | "ticket"
  | "incident"
  | "article"
  | "custom_object";

export interface CommandSurface {
  readonly surface: CommandSurfaceName;
  readonly object_types?: ReadonlyArray<CommandObjectType>;
}

/**
 * A snap-in command declaration.
 *
 * @experimental The proposal's command passes local/server manifest validation but remains
 * blocked by an upstream activation RPC. Do not treat successful generation or function
 * registration as live command support. Pairs with the experimental runtime adapter.
 */
export interface Command<Fn extends string = string> {
  readonly name: string;
  /** Required in v2 (checkCommands enforces it). Must match `^[A-Za-z][A-Za-z0-9_]*[A-Za-z0-9]$`. */
  readonly namespace: string;
  readonly description?: string;
  readonly function: Fn;
  readonly surfaces: ReadonlyArray<CommandSurface>;
  readonly usage_hint?: string;
}

export type HookType = "validate" | "activate" | "update" | "deactivate";

export interface Hook<Fn extends string = string> {
  readonly type: HookType;
  readonly function: Fn;
}

export interface Tag {
  readonly name: string;
  readonly description?: string;
}

export interface SnapKitAction<Fn extends string = string> {
  readonly name: string;
  readonly description?: string;
  readonly function: Fn;
}

export interface SnapComponent<Fn extends string = string> {
  readonly name: string;
  readonly display_name: string;
  readonly description?: string;
  readonly surface: string;
  readonly snap_kit_action_name?: string;
  readonly snap_kit_body?: Record<string, unknown>;
  readonly initializer?: Fn;
}

export interface Import<Fn extends string = string> {
  readonly slug: string;
  readonly display_name: string;
  readonly description?: string;
  readonly extractor_function: Fn;
  readonly loader_function?: Fn;
  readonly allowed_connection_types?: ReadonlyArray<KeyringConnectionType>;
  readonly capabilities?: ReadonlyArray<string>;
  readonly domain_metadata?: Record<string, unknown>;
}

export interface EnvironmentVariable {
  readonly name: string;
  readonly description?: string;
  readonly type: "constant" | "keyring";
  readonly value: string;
  readonly path?: string;
}

export interface BuildConfig {
  readonly environment_variables?: ReadonlyArray<EnvironmentVariable>;
}

export type OperationMethodName =
  | "schema_handler"
  | "activate"
  | "deactivate"
  | "delete"
  | "validate";

export interface OperationMethod {
  readonly name: OperationMethodName;
}

export interface OperationExecuteOptions {
  readonly default_timeout?: number;
  readonly is_timeout_configurable?: boolean;
  readonly max_execution_timeout?: number;
}

export interface OperationMetadata {
  readonly mcp_hints?: Record<string, unknown>;
  readonly is_tool?: boolean;
  readonly is_mcp_tool?: boolean;
  readonly is_workflow_node?: boolean;
  readonly is_agent_skill?: boolean;
  readonly mcp_server?: string;
}

export interface ManifestScopeEntry {
  readonly scope: Scope;
  readonly optional?: boolean;
  readonly reason?: string;
}

export interface ManifestImpersonationScopeEntry {
  readonly act_as: ActAs;
  readonly scopes?: ReadonlyArray<ManifestScopeEntry>;
}

export interface ManifestAccessScopes {
  readonly self?: ReadonlyArray<ManifestScopeEntry>;
  readonly impersonation?: ReadonlyArray<ManifestImpersonationScopeEntry>;
}

/** The operation schema subset supported by this package. */
export type OperationSchemaField = Input;

export interface OperationCompositeSchema {
  readonly name: string;
  readonly description?: string;
  readonly fields: ReadonlyArray<OperationSchemaField>;
}

export interface OperationData {
  readonly fields?: ReadonlyArray<OperationSchemaField>;
  readonly composites?: ReadonlyArray<OperationCompositeSchema>;
}

export interface Operation<Fn extends string = string> {
  readonly name: string;
  readonly display_name: string;
  readonly description: string;
  /** The v2 platform accepts only an omitted or empty namespace. */
  readonly namespace?: "";
  readonly slug: string;
  readonly type: OperationType;
  readonly function: Fn;
  readonly keyrings?: ReadonlyArray<Keyring>;
  readonly inputs?: OperationData;
  readonly outputs?: OperationData;
  readonly labels?: ReadonlyArray<string>;
  readonly methods?: ReadonlyArray<OperationMethod>;
  readonly execute_options?: OperationExecuteOptions;
  readonly metadata?: OperationMetadata;
  readonly static_scopes?: ManifestAccessScopes;
}

const operationKeys = {
  name: true,
  display_name: true,
  description: true,
  namespace: true,
  slug: true,
  type: true,
  function: true,
  keyrings: true,
  inputs: true,
  outputs: true,
  labels: true,
  methods: true,
  execute_options: true,
  metadata: true,
  static_scopes: true,
} as const satisfies Readonly<Record<keyof Operation, true>>;

const knownOperationKeys = new Set<string>(Object.keys(operationKeys));

export interface InteractionHandlerDefinition<Fn extends string = string> {
  readonly initializer: Fn;
  readonly snap_kit_action_name: string;
}

export interface SnapInConfigurationHandler<Fn extends string = string> {
  readonly organization?: InteractionHandlerDefinition<Fn>;
  readonly user?: InteractionHandlerDefinition<Fn>;
}

export interface Dashboard {
  readonly name: string;
  readonly body: Record<string, unknown>;
}

export interface Widget {
  readonly name: string;
  readonly body: Record<string, unknown>;
}

export interface WorkflowTemplate {
  readonly name: string;
  readonly body: Record<string, unknown>;
}

export interface RecordTemplates {
  readonly workflows?: ReadonlyArray<WorkflowTemplate>;
}

export interface Workflow {
  readonly name: string;
  readonly template_reference_key: string;
  readonly should_activate?: boolean;
}

export type CustomSchemaScalarFieldType =
  | "bool"
  | "composite"
  | "date"
  | "double"
  | "enum"
  | "id"
  | "int"
  | "json_value"
  | "rich_text"
  | "struct"
  | "text"
  | "timestamp"
  | "tokens"
  | "uenum"
  | "unknown";

/** Minimum discriminator contract for a custom-schema field; extra platform metadata stays forward-compatible. */
interface CustomSchemaFieldBase {
  readonly name: string;
  readonly description?: string;
  readonly is_required?: boolean;
  readonly is_filterable?: boolean;
  readonly ui?: UiHint & Readonly<Record<string, unknown>>;
}

export type CustomSchemaField = CustomSchemaFieldBase & Readonly<Record<string, unknown>> & (
  | {
      readonly field_type: "array";
      readonly base_type: Exclude<CustomSchemaScalarFieldType, "unknown">;
    }
  | {
      readonly field_type: CustomSchemaScalarFieldType;
      readonly base_type?: never;
    }
);

export interface AppSchemaFragmentBody {
  readonly [key: string]: unknown;
  readonly type: "app_fragment";
  readonly leaf_type: string;
  readonly description: string;
  readonly is_custom_leaf_type: boolean;
  readonly fields: ReadonlyArray<CustomSchemaField>;
}

export type CustomSchemaFragment =
  | {
      readonly leaf_type: string;
      readonly id_prefix: string;
      readonly body: AppSchemaFragmentBody & { readonly is_custom_leaf_type: true };
    }
  | {
      readonly leaf_type: string;
      readonly id_prefix?: never;
      readonly body: AppSchemaFragmentBody & { readonly is_custom_leaf_type: false };
    };

export interface CustomObjectFragmentOptions {
  readonly leafType: string;
  readonly idPrefix: string;
  readonly description: string;
  readonly fields: ReadonlyArray<CustomSchemaField>;
}

/** Builds the server-validated app fragment that defines a snap-in-owned custom leaf type. */
export const customObjectFragment = (
  options: CustomObjectFragmentOptions,
): CustomSchemaFragment => {
  const fragment = {
    leaf_type: options.leafType,
    id_prefix: options.idPrefix,
    body: {
      type: "app_fragment",
      leaf_type: options.leafType,
      description: options.description,
      is_custom_leaf_type: true,
      fields: options.fields,
    },
  } satisfies CustomSchemaFragment;
  assertCustomSchemaFragment(fragment, "customObjectFragment");
  return fragment;
};

export interface Channel {
  readonly name: string;
  readonly display_name: string;
  readonly ticket_capabilities?: ReadonlyArray<string>;
  readonly conversation_capabilities?: ReadonlyArray<string>;
}

export interface ComplianceConfig {
  readonly hipaa?: boolean;
}

export interface McpServer {
  readonly name: string;
  readonly description?: string;
  readonly server_type: "remote" | "local";
  readonly slug: string;
  readonly url?: string;
  /**
   * Keyring/connection types this MCP server uses — the same value domain as a keyring's
   * `types[]`: a built-in, a declared `keyring_types[].id`, or a `rawConnectionType()` escape.
   * Bound by {@link defineManifest}'s connection-type check so a typo is a compile error.
   */
  readonly keyring_types?: ReadonlyArray<KeyringConnectionType>;
}

/**
 * An AI-agent plan.
 *
 * Skills are referenced ONLY by `skill_artifact_id` (an external artifact). Inline `skills[]`
 * typing — with its trigger cross-reference, per-plan key-uniqueness, and field-limit backstop —
 * was intentionally removed while skills move out of the manifest to external artifact
 * references, so modeling inline skills here would type-check a shape the platform is retiring.
 * Author skills as an artifact and point `skill_artifact_id` at it.
 */
export interface AiAgentPlanDefinition {
  readonly slug: string;
  readonly name: string;
  readonly description: string;
  readonly guidance?: string;
  readonly skill_artifact_id?: string;
}

/**
 * The typed snap-in manifest. `Fn` is the union of valid function names — every field
 * that references a function (`functions[].name`, `automations[].function`,
 * `commands[].function`, hooks, operations, imports, event-source/config-handler
 * initializers) is bound to it. {@link defineManifest} binds `Fn` to the keys of your
 * `functionFactory`, so a reference to a handler that doesn't exist is a compile error.
 * Left unbound (`Fn = string`) for consumers like {@link toYaml} that don't care.
 */
export interface Manifest<Fn extends string = string> {
  readonly version: "2";
  readonly name: string;
  readonly description?: string;
  readonly labels?: ReadonlyArray<string>;
  readonly service_account?: ServiceAccount;
  readonly changelog?: string;
  readonly developer_keyrings?: ReadonlyArray<DeveloperKeyring>;
  readonly event_sources?: ScopedEventSources<Fn>;
  readonly keyrings?: ScopedKeyrings;
  readonly tags?: ReadonlyArray<Tag>;
  readonly automations?: ReadonlyArray<Automation<Fn>>;
  readonly hooks?: ReadonlyArray<Hook<Fn>>;
  readonly inputs?: ScopedInputs;
  readonly functions?: ReadonlyArray<FunctionDef<Fn>>;
  readonly commands?: ReadonlyArray<Command<Fn>>;
  readonly snap_kit_actions?: ReadonlyArray<SnapKitAction<Fn>>;
  readonly snap_components?: ReadonlyArray<SnapComponent<Fn>>;
  readonly imports?: ReadonlyArray<Import<Fn>>;
  readonly keyring_types?: ReadonlyArray<KeyringType>;
  readonly build_config?: BuildConfig;
  readonly operations?: ReadonlyArray<Operation<Fn>>;
  readonly configuration_handler?: SnapInConfigurationHandler<Fn>;
  readonly dashboards?: ReadonlyArray<Dashboard>;
  readonly widgets?: ReadonlyArray<Widget>;
  readonly templates?: RecordTemplates;
  readonly channels?: ReadonlyArray<Channel>;
  readonly custom_schema_fragments?: ReadonlyArray<CustomSchemaFragment>;
  readonly compliance?: ComplianceConfig;
  readonly workflows?: ReadonlyArray<Workflow>;
  readonly mcp_servers?: ReadonlyArray<McpServer>;
  readonly ai_agent_plans?: ReadonlyArray<AiAgentPlanDefinition>;
}

// Bind wire-format names to literal factory keys. Compile-time checks cover function
// declarations, automation sources, duplicates, and connection types; generation-time
// checks catch casts plus broader uniqueness and cross-reference failures. Raw connection
// escapes are intentionally indistinguishable from ordinary strings at runtime.

/** The value the manifest binds against: a map of function name → handler. */
export type FunctionFactory = Record<string, unknown>;

type FactoryKeys<F> = Extract<keyof F, string>;

type DeclaredFunctionNames<M> = M extends { readonly functions?: infer FS }
  ? FS extends ReadonlyArray<{ readonly name: infer N }>
    ? Extract<N, string>
    : never
  : never;

type SourceNamesIn<A> = A extends ReadonlyArray<{ readonly name: infer N }>
  ? Extract<N, string>
  : never;

type DeclaredSourceNames<M> = M extends {
  readonly event_sources?: {
    readonly organization?: infer O;
    readonly user?: infer U;
  };
}
  ? SourceNamesIn<O> | SourceNamesIn<U>
  : never;

type AutomationSources<M> = M extends { readonly automations?: infer A }
  ? A extends ReadonlyArray<{ readonly source: infer S }>
    ? Extract<S, string>
    : never
  : never;

/** Factory keys with no matching `functions[]` entry — must be empty. */
type MissingFunctionDeclarations<F, M> = Exclude<
  FactoryKeys<F>,
  DeclaredFunctionNames<M>
>;

/** Automation sources that don't name any declared event source — must be empty. */
type UnknownAutomationSources<M> = Exclude<
  AutomationSources<M>,
  DeclaredSourceNames<M>
>;

// A non-empty error set adds an impossible named property that exposes the offenders.
type ExhaustiveFunctionsCheck<F, M> = [MissingFunctionDeclarations<F, M>] extends [
  never,
]
  ? unknown
  : {
      readonly __EVERY_functionFactory_KEY_MUST_BE_DECLARED_IN_functions__: MissingFunctionDeclarations<
        F,
        M
      >;
    };

type AutomationSourcesCheck<M> = [UnknownAutomationSources<M>] extends [never]
  ? unknown
  : {
      readonly __automation_source_MUST_MATCH_A_DECLARED_event_source__: UnknownAutomationSources<M>;
    };

// Distribute over array elements: matching an optional field across the whole array lets
// an omitted sibling add `undefined` and collapse the inferred member type to `never`.
// Regression: test/manifest-binding.test.ts sibling-omits-field cases.

/** The keyring ids the manifest declares in `keyring_types[]` — the local half of a valid connection type. */
type DeclaredKeyringTypeIds<M> = M extends { readonly keyring_types?: infer KTs }
  ? KTs extends ReadonlyArray<infer KT>
    ? KT extends { readonly id?: infer I }
      ? Extract<I, string>
      : never
    : never
  : never;

type ConnectionTypesIn<A> = A extends ReadonlyArray<infer El>
  ? El extends { readonly types?: infer T }
    ? NonNullable<T> extends ReadonlyArray<infer E>
      ? Extract<E, string>
      : never
    : never
  : never;

/** imports[].allowed_connection_types — the same value domain as a keyring's `types[]`. */
type AllowedConnectionTypesIn<I> = I extends ReadonlyArray<infer El>
  ? El extends { readonly allowed_connection_types?: infer T }
    ? NonNullable<T> extends ReadonlyArray<infer E>
      ? Extract<E, string>
      : never
    : never
  : never;

/** mcp_servers[].keyring_types — again the same connection-type value domain. */
type McpKeyringTypesIn<S> = S extends ReadonlyArray<infer El>
  ? El extends { readonly keyring_types?: infer T }
    ? NonNullable<T> extends ReadonlyArray<infer E>
      ? Extract<E, string>
      : never
    : never
  : never;

/**
 * Every connection type used by a keyring's `types[]` (org + user), an import's
 * `allowed_connection_types`, or an mcp_server's `keyring_types` — all one value domain.
 */
type UsedConnectionTypes<M> =
  | (M extends {
      readonly keyrings?: {
        readonly organization?: infer O;
        readonly user?: infer U;
      };
    }
      ? ConnectionTypesIn<O> | ConnectionTypesIn<U>
      : never)
  | (M extends { readonly imports?: infer I }
      ? AllowedConnectionTypesIn<I>
      : never)
  | (M extends { readonly mcp_servers?: infer S }
      ? McpKeyringTypesIn<S>
      : never);

// Leave only unknown connection types; the branded raw escape is allowed explicitly.
type UnknownConnectionTypes<M> = Exclude<
  UsedConnectionTypes<M>,
  BuiltInConnectionType | DeclaredKeyringTypeIds<M> | CustomConnectionType
>;

type ConnectionTypesCheck<M> = [UnknownConnectionTypes<M>] extends [never]
  ? unknown
  : {
      readonly __connection_types_MUST_BE_a_builtin_or_a_declared_keyring_types_id__: UnknownConnectionTypes<M>;
    };

type NamesOf<T> = {
  readonly [K in keyof T]: T[K] extends { readonly name: infer N } ? N : never;
};

/** Walk a tuple, remembering seen members; a member already in `Seen` is a duplicate. */
type DuplicateStrings<
  T extends readonly unknown[],
  Seen = never,
  Dup = never,
> = T extends readonly [infer H, ...infer R]
  ? DuplicateStrings<R, Seen | H, H extends Seen ? Dup | H : Dup>
  : Dup;

/** Function names declared more than once — the platform rejects these (`found duplicate function names`). */
type DuplicateFunctionNames<M> = M extends { readonly functions?: infer FS }
  ? FS extends readonly unknown[]
    ? DuplicateStrings<NamesOf<FS>>
    : never
  : never;

type UniqueFunctionsCheck<M> = [DuplicateFunctionNames<M>] extends [never]
  ? unknown
  : {
      readonly __functions_MUST_have_unique_names__: DuplicateFunctionNames<M>;
    };

type OperationsIn<M> = M extends { readonly operations?: infer Ops }
  ? Ops extends ReadonlyArray<infer Op>
    ? Op
    : never
  : never;

type UnknownOperationKeys<M> = OperationsIn<M> extends infer Op
  ? Op extends unknown
    ? Exclude<keyof Op, keyof Operation>
    : never
  : never;

type OperationKeysCheck<M> = [UnknownOperationKeys<M>] extends [never]
  ? unknown
  : {
      readonly __operations_MUST_NOT_have_unknown_properties__: UnknownOperationKeys<M>;
    };

/**
 * Type the manifest as code and bind it to your function factory.
 *
 * @example
 * ```ts
 * import { functionFactory } from "./src/index";
 * export default Manifest.defineManifest(functionFactory, {
 *   version: "2",
 *   name: "hello-snap-in",
 *   functions: [{ name: "on_ticket_created" }], // ← must be a factory key
 *   automations: [{
 *     name: "greet",
 *     source: "ticket-created-source",           // ← must be a declared event source
 *     event_types: ["work_created"],
 *     function: "on_ticket_created",              // ← must be a factory key
 *   }],
 * });
 * ```
 */
export function defineManifest<
  const F extends FunctionFactory,
  const M extends Manifest<FactoryKeys<F>>,
>(
  factory: F,
  manifest: M &
    ExhaustiveFunctionsCheck<F, M> &
    UniqueFunctionsCheck<M> &
    AutomationSourcesCheck<M> &
    ConnectionTypesCheck<M> &
    OperationKeysCheck<M>,
): Manifest {
  const m = manifest as unknown as Manifest;
  assertManifestBinding(factory, m);
  return m;
}

/** The members of `values` that appear more than once, in first-seen order. */
const findDuplicates = (values: ReadonlyArray<string>): ReadonlyArray<string> => {
  const seen = new Set<string>();
  const dups = new Set<string>();
  for (const v of values) {
    if (seen.has(v)) dups.add(v);
    else seen.add(v);
  }
  return [...dups];
};

/** Render a set of valid names for an error message, or `<none>` when empty. */
const nameList = (values: Iterable<string>): string => {
  const arr = [...values];
  return arr.length > 0 ? arr.join(", ") : "<none>";
};

const assertCustomSchemaFragment = (
  fragment: CustomSchemaFragment,
  context: string,
): void => {
  if (fragment.leaf_type.trim() === "" || /\s/.test(fragment.leaf_type)) {
    throw new Error(`${context}: leafType must be non-empty and contain no whitespace.`);
  }
  if (fragment.body.leaf_type !== fragment.leaf_type) {
    throw new Error(`${context}: body leaf_type must match ${fragment.leaf_type}.`);
  }
  if (fragment.body.description.trim() === "") {
    throw new Error(`${context}: description must be non-empty.`);
  }
  if (
    fragment.body.is_custom_leaf_type &&
    (fragment.id_prefix === undefined || !/^[A-Z]{2,10}$/.test(fragment.id_prefix))
  ) {
    throw new Error(`${context}: idPrefix must contain 2-10 uppercase ASCII letters.`);
  }
  const duplicates = findDuplicates(fragment.body.fields.map((field) => field.name));
  if (duplicates.length > 0) {
    throw new Error(`${context}: duplicate field names: ${duplicates.join(", ")}.`);
  }
};

const assertManifestBinding = (factory: FunctionFactory, m: Manifest): void => {
  for (const fn of m.functions ?? []) {
    const interval = fn.config?.runtime?.min_interval;
    if (interval !== undefined && interval < 10) {
      throw new Error(`function "${fn.name}" runtime.min_interval must be at least 10 seconds.`);
    }
  }
  for (const fragment of m.custom_schema_fragments ?? []) {
    assertCustomSchemaFragment(fragment, `custom schema fragment "${fragment.leaf_type}"`);
  }

  // Runtime backstop for casts that bypass defineManifest's compile-time checks.
  for (const operation of m.operations ?? []) {
    if (operation.namespace !== undefined && operation.namespace !== "") {
      throw new Error(`operation "${operation.name}" must omit namespace or use an empty string.`);
    }
    const unknownKeys = Object.keys(operation).filter(
      (key) => !knownOperationKeys.has(key),
    );
    if (unknownKeys.length > 0) {
      throw new Error(
        `operation "${operation.name}" has unknown properties: ${unknownKeys.join(", ")}.`,
      );
    }
  }

  const factoryKeys = new Set(Object.keys(factory));
  const declaredFunctionNames = (m.functions ?? []).map((f) => f.name);
  const declared = new Set(declaredFunctionNames);

  // Bind factory keys and functions[] in both directions.
  for (const name of declared) {
    if (!factoryKeys.has(name)) {
      throw new Error(
        `manifest functions[] declares "${name}", which is not a key of functionFactory ` +
          `(have: ${nameList(factoryKeys)}).`,
      );
    }
  }
  for (const key of factoryKeys) {
    if (!declared.has(key)) {
      throw new Error(
        `functionFactory exports "${key}" but no functions[] entry declares it — ` +
          `add { name: "${key}" } to the manifest.`,
      );
    }
  }

  // Platform manifest-v2 uniqueness rules.
  const orgKeyrings = m.keyrings?.organization ?? [];
  const userKeyrings = m.keyrings?.user ?? [];
  const uniqueNamespaces: ReadonlyArray<
    readonly [string, ReadonlyArray<string | undefined>]
  > = [
    ["functions[].name", declaredFunctionNames],
    ["automations[].name", (m.automations ?? []).map((a) => a.name)],
    [
      "event_sources names (organization + user)",
      [
        ...(m.event_sources?.organization ?? []).map((s) => s.name),
        ...(m.event_sources?.user ?? []).map((s) => s.name),
      ],
    ],
    [
      "keyring names (organization + user + developer_keyrings)",
      [
        ...orgKeyrings.map((k) => k.name),
        ...userKeyrings.map((k) => k.name),
        ...(m.developer_keyrings ?? []).map((k) => k.name),
      ],
    ],
    ["keyring_types[].id", (m.keyring_types ?? []).map((k) => k.id)],
    ["operations[].slug", (m.operations ?? []).map((o) => o.slug)],
    ["operations[].name", (m.operations ?? []).map((o) => o.name)],
    ["commands[].name", (m.commands ?? []).map((c) => c.name)],
    [
      "inputs names (organization + user)",
      [
        ...(m.inputs?.organization ?? []).map((i) => i.name),
        ...(m.inputs?.user ?? []).map((i) => i.name),
      ],
    ],
    ["snap_kit_actions[].name", (m.snap_kit_actions ?? []).map((s) => s.name)],
    ["snap_components[].name", (m.snap_components ?? []).map((s) => s.name)],
    ["tags[].name", (m.tags ?? []).map((t) => t.name)],
    ["imports[].slug", (m.imports ?? []).map((i) => i.slug)],
    ["mcp_servers[].slug", (m.mcp_servers ?? []).map((s) => s.slug)],
    ["ai_agent_plans[].slug", (m.ai_agent_plans ?? []).map((p) => p.slug)],
    ["dashboards[].name", (m.dashboards ?? []).map((d) => d.name)],
    ["widgets[].name", (m.widgets ?? []).map((w) => w.name)],
    [
      "templates.workflows[].name",
      (m.templates?.workflows ?? []).map((w) => w.name),
    ],
    [
      "custom_schema_fragments[].leaf_type",
      (m.custom_schema_fragments ?? []).map((f) => f.leaf_type),
    ],
    ["hooks[].type", (m.hooks ?? []).map((h) => h.type)],
  ];
  for (const [label, values] of uniqueNamespaces) {
    const defined = values.filter((v): v is string => v !== undefined);
    const dups = findDuplicates(defined);
    if (dups.length > 0) {
      throw new Error(
        `manifest has duplicate ${label}: ${dups.join(", ")}. Each must be unique.`,
      );
    }
  }

  // Every function reference must point at a declaration.
  const cfgOrg = m.configuration_handler?.organization;
  const cfgUser = m.configuration_handler?.user;
  const allEventSources = [
    ...(m.event_sources?.organization ?? []),
    ...(m.event_sources?.user ?? []),
  ];
  const functionRefs: ReadonlyArray<readonly [string, string | undefined]> = [
    ...(m.automations ?? []).map((a) => [`automation "${a.name}"`, a.function] as const),
    ...allEventSources.map(
      (s) => [`event source "${s.name}" function`, s.function] as const,
    ),
    ...(m.commands ?? []).map((c) => [`command "${c.name}"`, c.function] as const),
    ...(m.hooks ?? []).map((h) => [`hook "${h.type}"`, h.function] as const),
    ...(m.snap_kit_actions ?? []).map(
      (s) => [`snap_kit_action "${s.name}"`, s.function] as const,
    ),
    ...(m.operations ?? []).map((o) => [`operation "${o.name}"`, o.function] as const),
    ...(m.imports ?? []).flatMap((i) => [
      [`import "${i.slug}" extractor_function`, i.extractor_function] as const,
      [`import "${i.slug}" loader_function`, i.loader_function] as const,
    ]),
    ...(m.snap_components ?? []).map(
      (s) => [`snap_component "${s.name}" initializer`, s.initializer] as const,
    ),
    ...(cfgOrg
      ? [["configuration_handler.organization initializer", cfgOrg.initializer] as const]
      : []),
    ...(cfgUser
      ? [["configuration_handler.user initializer", cfgUser.initializer] as const]
      : []),
  ];
  for (const [where, ref] of functionRefs) {
    if (ref !== undefined && !declared.has(ref)) {
      throw new Error(
        `${where} references function "${ref}", which is not declared in functions[] ` +
          `(declared: ${nameList(declared)}).`,
      );
    }
  }

  // Every automation source must be declared.
  const sourceNames = new Set([
    ...(m.event_sources?.organization ?? []).map((s) => s.name),
    ...(m.event_sources?.user ?? []).map((s) => s.name),
  ]);
  for (const a of m.automations ?? []) {
    if (!sourceNames.has(a.source)) {
      throw new Error(
        `automation "${a.name}" references event source "${a.source}", which is not declared ` +
          `in event_sources (declared: ${nameList(sourceNames)}).`,
      );
    }
  }

  // snap_kit_action_name must resolve.
  const skaNames = new Set((m.snap_kit_actions ?? []).map((s) => s.name));
  const skaRefs: ReadonlyArray<readonly [string, string | undefined]> = [
    ...(m.snap_components ?? []).map(
      (s) => [`snap_component "${s.name}"`, s.snap_kit_action_name] as const,
    ),
    ...(cfgOrg
      ? [["configuration_handler.organization", cfgOrg.snap_kit_action_name] as const]
      : []),
    ...(cfgUser
      ? [["configuration_handler.user", cfgUser.snap_kit_action_name] as const]
      : []),
  ];
  for (const [where, ref] of skaRefs) {
    // The platform treats an empty snap_kit_action_name as absent (not a dangling
    // reference), so only a non-empty name that resolves to nothing is an error.
    if (ref !== undefined && ref !== "" && !skaNames.has(ref)) {
      throw new Error(
        `${where} references snap_kit_action "${ref}", which is not declared in ` +
          `snap_kit_actions (declared: ${nameList(skaNames)}).`,
      );
    }
  }

  // Workflow template references must resolve.
  const templateNames = new Set((m.templates?.workflows ?? []).map((w) => w.name));
  for (const w of m.workflows ?? []) {
    if (!templateNames.has(w.template_reference_key)) {
      throw new Error(
        `workflow "${w.name}" references template_reference_key "${w.template_reference_key}", ` +
          `which is not declared in templates.workflows (declared: ${nameList(templateNames)}).`,
      );
    }
  }

  // Keyring environment variables must resolve.
  const devKeyringNames = new Set((m.developer_keyrings ?? []).map((k) => k.name));
  for (const v of m.build_config?.environment_variables ?? []) {
    if (v.type === "keyring" && !devKeyringNames.has(v.value)) {
      throw new Error(
        `build_config environment variable "${v.name}" (type: keyring) references "${v.value}", ` +
          `which is not declared in developer_keyrings (declared: ${nameList(devKeyringNames)}).`,
      );
    }
  }

  // Event-source connections must resolve.
  const keyringNames = new Set([
    ...orgKeyrings.map((k) => k.name),
    ...userKeyrings.map((k) => k.name),
    ...(m.developer_keyrings ?? []).map((k) => k.name),
  ]);
  const eventSources = [
    ...(m.event_sources?.organization ?? []),
    ...(m.event_sources?.user ?? []),
  ];
  for (const es of eventSources) {
    const connections = [
      ...(es.connection !== undefined ? [es.connection] : []),
      ...(es.connections ?? []).map((c) => c.name),
    ];
    for (const conn of connections) {
      if (!keyringNames.has(conn)) {
        throw new Error(
          `event source "${es.name}" references connection "${conn}", which is not a declared ` +
            `keyring (declared: ${nameList(keyringNames)}).`,
        );
      }
    }
  }

  // The platform rejects duplicate connection types within one import.
  for (const imp of m.imports ?? []) {
    const connDups = findDuplicates([...(imp.allowed_connection_types ?? [])]);
    if (connDups.length > 0) {
      throw new Error(
        `import "${imp.slug}" lists duplicate allowed_connection_types: ${connDups.join(", ")}. ` +
          `Each connection type may appear only once.`,
      );
    }
  }

  // Inline skills remain intentionally unmodeled while the platform moves them to artifacts.

  // Snapshot of generated-schema limits and validator rules. Keep mirrored bounds aligned
  // with the server; snapshots can drift, so authenticated server validation is authoritative.
  // Sources: archetype_snap_in_version.gen.go, archetype_composites.gen.go,
  // template_validator_v2.go.
  const violations: string[] = [];

  const checkLen = (
    label: string,
    value: string | undefined,
    max: number,
    min = 0,
  ): void => {
    if (value === undefined) return;
    if (value.length > max) {
      violations.push(`${label} is ${value.length} chars; the platform max is ${max}`);
    }
    if (min > 0 && value.length < min) {
      violations.push(`${label} is ${value.length} chars; the platform min is ${min}`);
    }
  };
  const checkCount = (label: string, count: number, max: number): void => {
    if (count > max) {
      violations.push(`${label} has ${count} entries; the platform max is ${max}`);
    }
  };

  // Top-level scalars + labels.
  checkLen("name", m.name, 256);
  checkLen("description", m.description, 1024);
  checkLen("changelog", m.changelog, 65536);
  (m.labels ?? []).forEach((l, i) => checkLen(`labels[${i}]`, l, 64));
  checkLen("service_account.display_name", m.service_account?.display_name, 256);

  for (const a of m.automations ?? []) {
    checkLen(`automation "${a.name}" name`, a.name, 256);
    a.event_types.forEach((e, i) =>
      checkLen(`automation "${a.name}" event_types[${i}]`, e, 1024),
    );
  }

  for (const es of eventSources) {
    checkLen(`event source "${es.name}" name`, es.name, 256);
    checkLen(`event source "${es.name}" description`, es.description, 1024);
    checkLen(`event source "${es.name}" display_name`, es.display_name, 256);
    checkLen(`event source "${es.name}" setup_instructions`, es.setup_instructions, 10240);
  }

  for (const k of [...orgKeyrings, ...userKeyrings, ...(m.developer_keyrings ?? [])]) {
    checkLen(`keyring "${k.name}" name`, k.name, 256);
    checkLen(`keyring "${k.name}" description`, k.description, 1024);
    checkLen(`keyring "${k.name}" display_name`, k.display_name, 256);
  }

  for (const kt of m.keyring_types ?? []) {
    const id = kt.id ?? kt.name ?? "<unnamed>";
    checkLen(`keyring_type "${id}" id`, kt.id, 256);
    checkLen(`keyring_type "${id}" name`, kt.name, 256);
    checkLen(`keyring_type "${id}" description`, kt.description, 1024);
    checkLen(`keyring_type "${id}" domain`, kt.domain, 255, 1);
    checkLen(`keyring_type "${id}" scope_delimiter`, kt.scope_delimiter, 2, 1);
    checkLen(`keyring_type "${id}" external_system_name`, kt.external_system_name, Infinity, 1);
    checkCount(`keyring_type "${id}" scopes`, (kt.scopes ?? []).length, 100);
  }

  for (const imp of m.imports ?? []) {
    checkLen(`import "${imp.slug}" slug`, imp.slug, 1024, 3);
    checkLen(`import "${imp.slug}" display_name`, imp.display_name, 1024);
    checkLen(`import "${imp.slug}" description`, imp.description, 1024);
    checkLen(`import "${imp.slug}" extractor_function`, imp.extractor_function, 1024);
    checkLen(`import "${imp.slug}" loader_function`, imp.loader_function, 1024);
    (imp.capabilities ?? []).forEach((c, i) =>
      checkLen(`import "${imp.slug}" capabilities[${i}]`, c, 256),
    );
  }

  for (const sc of m.snap_components ?? []) {
    checkLen(`snap_component "${sc.name}" name`, sc.name, 256);
    checkLen(`snap_component "${sc.name}" description`, sc.description, 1024);
    checkLen(`snap_component "${sc.name}" display_name`, sc.display_name, 256);
    checkLen(`snap_component "${sc.name}" snap_kit_action_name`, sc.snap_kit_action_name, 256);
    checkLen(`snap_component "${sc.name}" initializer`, sc.initializer, 256);
  }

  for (const op of m.operations ?? []) {
    (op.labels ?? []).forEach((l, i) =>
      checkLen(`operation "${op.name}" labels[${i}]`, l, 64),
    );
    checkCount(`operation "${op.name}" labels`, (op.labels ?? []).length, 16);
  }

  for (const s of m.mcp_servers ?? []) {
    checkLen(`mcp_server "${s.slug}" slug`, s.slug, 256);
    checkLen(`mcp_server "${s.slug}" name`, s.name, 256);
    checkLen(`mcp_server "${s.slug}" description`, s.description, 8192);
  }

  for (const plan of m.ai_agent_plans ?? []) {
    checkLen(`ai_agent_plan "${plan.slug}" slug`, plan.slug, 256);
    checkLen(`ai_agent_plan "${plan.slug}" name`, plan.name, 256);
    checkLen(`ai_agent_plan "${plan.slug}" description`, plan.description, 1024);
    checkLen(`ai_agent_plan "${plan.slug}" guidance`, plan.guidance, 65536);
  }

  for (const d of m.dashboards ?? []) checkLen(`dashboard "${d.name}" name`, d.name, 256);
  for (const w of m.widgets ?? []) checkLen(`widget "${w.name}" name`, w.name, 256);
  for (const wt of m.templates?.workflows ?? [])
    checkLen(`templates.workflows "${wt.name}" name`, wt.name, 256);

  // Top-level collection count caps (version schema MaxItems).
  checkCount("functions", (m.functions ?? []).length, 20);
  checkCount("automations", (m.automations ?? []).length, 20);
  checkCount("tags", (m.tags ?? []).length, 20);
  checkCount("snap_kit_actions", (m.snap_kit_actions ?? []).length, 20);
  checkCount("snap_components", (m.snap_components ?? []).length, 20);
  checkCount("commands", (m.commands ?? []).length, 20);
  checkCount("imports", (m.imports ?? []).length, 20);
  checkCount("keyring_types", (m.keyring_types ?? []).length, 20);
  checkCount("mcp_servers", (m.mcp_servers ?? []).length, 20);
  checkCount("ai_agent_plans", (m.ai_agent_plans ?? []).length, 20);
  checkCount("custom_schema_fragments", (m.custom_schema_fragments ?? []).length, 20);
  checkCount("workflows", (m.workflows ?? []).length, 20);
  checkCount("templates.workflows", (m.templates?.workflows ?? []).length, 20);
  checkCount("event_sources.organization", (m.event_sources?.organization ?? []).length, 20);
  checkCount("event_sources.user", (m.event_sources?.user ?? []).length, 20);
  checkCount("keyrings.organization", orgKeyrings.length, 20);
  checkCount("keyrings.user", userKeyrings.length, 20);
  checkCount("developer_keyrings", (m.developer_keyrings ?? []).length, 20);
  checkCount("dashboards", (m.dashboards ?? []).length, 10);
  checkCount("widgets", (m.widgets ?? []).length, 50);
  checkCount("inputs.organization", (m.inputs?.organization ?? []).length, 50);
  checkCount("inputs.user", (m.inputs?.user ?? []).length, 50);
  checkCount("labels", (m.labels ?? []).length, 16);

  // --- Structural rules the type layer can't express (template_validator_v2.go). ---
  // Every keyring must declare at least one connection type (validateKeyring: len(types) < 1).
  for (const k of [...orgKeyrings, ...userKeyrings]) {
    if ((k.types?.length ?? 0) < 1) {
      violations.push(
        `keyring "${k.name}" declares no connection types; types[] must have at least one`,
      );
    }
  }

  // Event-source name may not contain '/' (isValidEventSourceName).
  for (const es of eventSources) {
    if (es.name.includes("/")) {
      violations.push(`event source "${es.name}" name may not contain '/'`);
    }
  }

  // `connections` (plural) is only allowed for flow-custom-webhook sources; a `connection`
  // (singular) is fine on any type. (validateEventSource: connections require the custom-webhook type.)
  for (const es of eventSources) {
    if ((es.connections?.length ?? 0) > 0 && es.type !== "flow-custom-webhook") {
      violations.push(
        `event source "${es.name}" sets connections[], which is only allowed for type ` +
          `"flow-custom-webhook" (this source is "${es.type}"); use a singular connection instead`,
      );
    }
  }

  // User event sources may carry neither a connection nor connections.
  for (const es of m.event_sources?.user ?? []) {
    if (es.connection !== undefined && es.connection !== "") {
      violations.push(`user event source "${es.name}" may not set a connection`);
    }
    if ((es.connections?.length ?? 0) > 0) {
      violations.push(`user event source "${es.name}" may not set connections`);
    }
  }

  // Do not mirror checkInputs' apparent timestamp/date/[]bool ban: it compares fresh
  // string pointers, while registryLib.ValidateCustomSchema accepts those values. Leave
  // this rule to the server. Source: template_validator_v2.go checkInputs.

  if (violations.length > 0) {
    throw new Error(
      `manifest violates platform field constraints:\n  - ${violations.join("\n  - ")}`,
    );
  }
};

/**
 * Recursively drop `undefined` properties so they don't emit as `null`.
 *
 * The manifest must be a plain, JSON-serializable tree: cycles would recurse forever
 * and a non-plain object (a `Date`, `Map`, class instance, …) would serialize to a
 * shape the platform can't parse. Both are caught here with a clear message rather
 * than producing a silently corrupt `manifest.yaml`. `seen` tracks the current
 * recursion path only (added on enter, removed on exit) so a value legitimately
 * reused in sibling positions is fine — only a true back-edge is a cycle.
 */
const prune = (value: unknown, seen: WeakSet<object> = new WeakSet()): unknown => {
  if (value === null || typeof value !== "object") return value;
  if (seen.has(value)) {
    throw new Error(
      "manifest contains a circular reference; it must be a plain, JSON-serializable tree.",
    );
  }
  if (Array.isArray(value)) {
    seen.add(value);
    const out = value.map((v) => prune(v, seen));
    seen.delete(value);
    return out;
  }
  const proto = Object.getPrototypeOf(value) as object | null;
  if (proto !== Object.prototype && proto !== null) {
    const ctor = (value as { constructor?: { name?: string } }).constructor?.name;
    throw new Error(
      `manifest contains a non-plain object${ctor ? ` (${ctor})` : ""}; only plain objects, ` +
        `arrays, strings, numbers, and booleans are allowed (the manifest must be ` +
        `JSON-serializable).`,
    );
  }
  seen.add(value);
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(value)) {
    if (v !== undefined) out[k] = prune(v, seen);
  }
  seen.delete(value);
  return out;
};

export const toYaml = (
  manifest: Manifest,
  options: { readonly header?: boolean } = {},
): string => {
  const body = YAML.stringify(prune(manifest), { lineWidth: 0 });
  if (options.header === false) return body;
  return (
    "# Generated from manifest.ts by `npm run manifest`. Do not edit by hand.\n" +
    body
  );
};
