// Local value-domain snapshots from DevRev platform contracts. Escapes keep open
// platform values representable; server validation remains authoritative.

type Primitive = string | number | bigint | boolean | symbol | null | undefined;

/**
 * Union of known `Known` literals that STILL accepts any `Base` value, while keeping
 * editor autocomplete + hover docs for the known members.
 *
 * The intersection prevents union reduction from collapsing known literals into `string`.
 * See microsoft/TypeScript#29729.
 */
export type LiteralUnion<Known extends Base, Base extends Primitive = string> =
  | Known
  | (Base & Record<never, never>);

declare const brand: unique symbol;
/** Nominal brand: `Brand<string, "X">` is a string you can only *produce* through a checkpoint. */
export type Brand<T, B extends string> = T & { readonly [brand]: B };

// Scope grammar catches common typos; rawScope covers custom or unmined values.

export type ScopeObjectName =
  | "access_control_entry" | "account" | "account_commerce_details" | "ai_agent"
  | "ai_agent_session" | "approval_config" | "approval_tracker" | "article"
  | "artifact" | "brand" | "capability" | "code_change" | "command" | "conversation"
  | "credit" | "credit_coupon" | "custom_object" | "dashboard" | "dataset" | "dev_org"
  | "dev_user" | "devu_invite" | "directory" | "engagement" | "enhancement"
  | "eval_dataset" | "eval_experiment" | "feature" | "group" | "incident" | "invoice"
  | "invoice_line_item" | "issue" | "job" | "keyring" | "license_assignment" | "link"
  | "linkable" | "mcp_server" | "meeting" | "metric" | "metric_definition"
  | "metric_set" | "metric_tracker" | "notification_content_template" | "oasis_data"
  | "observability_alert" | "observability_monitor" | "operation" | "opportunity"
  | "org_preferences" | "org_schedule" | "org_schedule_fragment" | "plug_setting"
  | "portal_preferences" | "pricing" | "product" | "question_answer" | "quote"
  | "record_template" | "rev_org" | "rev_user" | "role" | "role_set" | "runnable"
  | "score" | "service_plan" | "sku" | "sku_rule" | "sla" | "sla_tracker" | "snap_in"
  | "snap_in_package" | "snap_widget" | "space" | "survey" | "survey_response"
  | "svcacc" | "sync_history" | "sync_mapper_record" | "sync_snap_in" | "sync_unit"
  | "tag" | "task" | "ticket" | "uom" | "vista" | "web_crawler_job" | "widget"
  | "workflow";

/** Permission tiers on a scope. `all` subsumes read+write; some objects expose granular verbs. */
export type ScopeVerb = "read" | "write" | "all";

/**
 * A scope the `<object>:<verb>` catalog can't express (a `custom_object:<leaf>:<verb>`
 * triple, or an object not yet mined). Produced only through `rawScope`, so every
 * escape from the closed grammar is explicit at the call site.
 */
export type CustomScope = Brand<string, "Scope">;

/**
 * A service-account scope, `<object>:<verb>`. CLOSED over the catalog × {read,write,all}:
 * every legal pair autocompletes and a typo (`ticket:raed`, `tikcet:read`) is a compile
 * error. Genuinely custom scopes go through {@link rawScope}.
 */
export type Scope = `${ScopeObjectName}:${ScopeVerb}` | CustomScope;

/**
 * Escape hatch for a scope the closed grammar can't express (custom-object leaves, or an
 * object missing from the catalog). Prefer a plain `"object:verb"` literal wherever it
 * type-checks — reach for this only when it genuinely can't.
 */
export const rawScope = (scope: string): CustomScope => scope as CustomScope;

export const customObjectScope = (
  leafType: string,
  verb: ScopeVerb,
): CustomScope => {
  if (leafType.trim() === "" || /[:\s]/.test(leafType)) {
    throw new Error("customObjectScope: leafType must be non-empty and contain no whitespace or colon.");
  }
  return rawScope(`custom_object:${leafType}:${verb}`);
};

/** Impersonation target group. CLOSED — the platform rejects anything else. */
export type ActAs = "all_devusers" | "all_revusers" | "devusers_explicit";

// Cataloged and custom:<key> event types catch typos; rawEventType covers unmined values.

export type EventObjectName =
  | "account" | "conversation" | "custom_object" | "dev_user" | "part" | "rev_org" | "rev_user"
  | "sla_tracker" | "tag" | "timeline_entry" | "webhook" | "work";

export type EventVerb = "created" | "updated" | "deleted";

/** Documented DevRev webhook events plus the timer tick. */
export type DevRevEventType = `${EventObjectName}_${EventVerb}` | "timer.tick";

/**
 * An event type the catalog can't express yet. Produced only through `rawEventType`,
 * keeping the escape explicit.
 */
export type CustomEventType = Brand<string, "EventType">;

/**
 * An event type on a webhook/automation. CLOSED over the documented catalog plus the
 * `custom:<key>` convention: `work_created` autocompletes, `work_creatd` is a compile
 * error, `custom:*` is always allowed, and anything else goes through {@link rawEventType}.
 */
export type EventType = DevRevEventType | `custom:${string}` | CustomEventType;

/** Escape hatch for a documented event not yet in the catalog. Prefer a plain literal when it type-checks. */
export const rawEventType = (event: string): CustomEventType => event as CustomEventType;

/** devrev-webhook event category. CLOSED over the platform-supported values. */
export type EventCategory = "regular" | "system";

// defineManifest accepts built-ins and locally declared keyring type IDs.

export type BuiltInConnectionType =
  | "devrev-github-pat" | "devrev-github-oauth" | "devrev-bitbucket-oauth"
  | "devrev-intercom-oauth" | "devrev-stripe-token" | "devrev-sendgrid-api-key"
  | "devrev-clearbit-api-key" | "devrev-flow-secret" | "devrev-datadog-keys"
  | "devrev-slack-app" | "devrev-discord-app" | "devrev-google-oauth"
  | "devrev-domain-verification" | "devrev-pat" | "devrev-gcp-json" | "devrev-jira-oauth"
  | "devrev-confluence-oauth" | "devrev-google-calendar-oauth" | "devrev-google-big-query-oauth"
  | "devrev-snap-in-secret" | "devrev-hubspot-oauth" | "devrev-hubspot-pat"
  | "devrev-xero-oauth" | "devrev-outreach-oauth" | "devrev-360-dialog-oauth"
  | "devrev-gainsight-api-key" | "devrev-descope-secret" | "devrev-goodmeetings-oauth";

/**
 * A connection type the built-in catalog can't express — a built-in not yet mined into
 * {@link BuiltInConnectionType}. Produced only through {@link rawConnectionType}, so the
 * escape is explicit. A locally-declared keyring_types[].id does NOT need this: it's bound
 * by {@link defineManifest}.
 */
export type CustomConnectionType = Brand<string, "ConnectionType">;

/**
 * A keyring connection type. Built-ins autocomplete; a keyring the manifest declares in
 * `keyring_types[]` is also valid — {@link defineManifest} binds `types[]` to the
 * built-ins ∪ those declared ids and rejects anything else. For a built-in missing from
 * the catalog, use {@link rawConnectionType}.
 */
export type KeyringConnectionType = LiteralUnion<BuiltInConnectionType>;

/**
 * Escape hatch for a built-in connection type missing from the catalog. Prefer a plain
 * built-in literal or a declared keyring_types[].id wherever it type-checks.
 */
export const rawConnectionType = (type: string): CustomConnectionType =>
  type as CustomConnectionType;

/** keyring_types[].kind. CLOSED over the platform-supported snake-case values. */
export type KeyringKind =
  | "oauth2" | "secret" | "secret_short_lived" | "dcr_oauth2" | "dpop_oauth2";

/** AdaptableRequestConfig.type / Authorize.type. CLOSED over config and function. */
export type AdaptableRequestType = "config" | "function";

/** OAuth grant type. CLOSED over the platform-supported values. */
export type OAuthGrantType =
  | "authorization_code" | "authorization_code_basic_auth" | "client_credentials";

/** TokenField input rendering. CLOSED over the platform-supported values. */
export type TokenInputType = "text" | "password" | "email";

/**
 * A method the standard set can't express (`TRACE`, `CONNECT`, a non-standard verb).
 * Produced only through {@link rawHttpMethod}, so the escape stays explicit. The platform
 * only checks the field is non-nil, so this never rejects a value the server would accept.
 */
export type CustomHttpMethod = Brand<string, "HttpMethod">;

/**
 * HTTP method for an adaptable request. CLOSED over the standard verbs — the platform only
 * checks non-nil, but the common set is fixed, so `GET` autocompletes and a typo is a compile
 * error. A verb outside the set goes through {@link rawHttpMethod}.
 */
export type HttpMethod =
  | "GET" | "POST" | "PUT" | "PATCH" | "DELETE" | "HEAD" | "OPTIONS"
  | CustomHttpMethod;

/** Escape hatch for an HTTP method outside the standard set. Prefer a plain literal when it type-checks. */
export const rawHttpMethod = (method: string): CustomHttpMethod => method as CustomHttpMethod;

/** operation.type. CLOSED — flowCommon.OperationType {trigger,action,control,blocking}. */
export type OperationType = "trigger" | "action" | "control" | "blocking";

/** email-forward allowed_modifications. CLOSED — knowledge ModificationType. */
export type EmailModification =
  | "to_header_dropped" | "cc_header_dropped" | "reply_to_header_dropped";

// JQ is open text but compiled at version creation. Branding makes raw filters explicit.
// Source: snap_in_versions_create.go CompileJqFilter.

export type JqQuery = Brand<string, "JqQuery">;

/** A chunk of jq boolean expression, composed with and()/or()/not() and terminated by jqFilter(). */
export interface JqCondition {
  /** The raw jq boolean expression, e.g. `.type == "work_created"`. */
  readonly expr: string;
}

const jqStr = (v: string): string => JSON.stringify(v);
const jqPath = (segments: ReadonlyArray<string>): string => `.${segments.join(".")}`;

/** `.type == "<event>"` — matches the top-level event type. Known events autocomplete. */
export const eventTypeIs = (event: EventType): JqCondition => ({
  expr: `.type == ${jqStr(event)}`,
});

/**
 * Compares a field to an escaped string constant. Values such as `$user.id` remain
 * literal text; use {@link rawCondition} for variable, path, or expression comparisons.
 */
export const fieldEquals = (
  path: ReadonlyArray<string>,
  value: string,
): JqCondition => ({ expr: `${jqPath(path)} == ${jqStr(value)}` });

/** Escape hatch: drop in any raw jq boolean expression as a condition. */
export const rawCondition = (expr: string): JqCondition => ({ expr });

export const and = (...cs: ReadonlyArray<JqCondition>): JqCondition => ({
  expr: cs.map((c) => `(${c.expr})`).join(" and "),
});
export const or = (...cs: ReadonlyArray<JqCondition>): JqCondition => ({
  expr: cs.map((c) => `(${c.expr})`).join(" or "),
});
export const not = (c: JqCondition): JqCondition => ({ expr: `(${c.expr} | not)` });

/** Terminal: wrap a condition in the DevRev `if … then true else false end` shell. */
export const jqFilter = (c: JqCondition): JqQuery =>
  `if ${c.expr} then true else false end` as JqQuery;

/** Whole-filter escape hatch for jq the builder doesn't cover. Still returns the brand. */
export const rawJqFilter = (query: string): JqQuery => query as JqQuery;
