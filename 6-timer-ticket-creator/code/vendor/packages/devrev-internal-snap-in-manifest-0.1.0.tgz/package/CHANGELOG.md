# Changelog

## 0.1.0 — unreleased

- Provide an independent typed manifest builder and YAML generation.
- Check handler references, operation fields, namespaces, and supported values.
- Generate fail-closed shared-secret webhook policies with an explicit raw Rego escape hatch.
- Bind HMAC webhook policies to their required keyring connection so secrets remain outside
  generated manifests and use DevRev's actual flat Rego keyring shape.
- Add typed custom-object fragment, custom-object event-source, and custom-object scope
  builders; catalog `custom_object_created` as a known event.
- Add distributable license, explicit CommonJS module type, side-effect metadata, and
  package discovery keywords.

This is the initial local candidate. No version has been published to the team registry.
