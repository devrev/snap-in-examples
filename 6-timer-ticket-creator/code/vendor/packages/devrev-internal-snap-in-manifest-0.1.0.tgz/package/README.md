# @devrev-internal/snap-in-manifest

Model event sources, lifecycle hooks, timers, operation ports, and secret-gated webhooks.
Function references bind to handler exports. Server validation remains necessary, and
successful validation alone does not prove creation or activation.

Independent author-time helpers for DevRev v2 manifests. Local proposal version 0.1.0;
no dependency on Effect, the SDK, or the runtime package. `yaml` is used for generation.
Builders validate synchronously and fail during authoring or generation with
helper-specific messages. Invocation-time failures belong in the runtime package's
typed Effect channel.

```ts
import { Manifest } from "@devrev-internal/snap-in-manifest";
import { functionFactory } from "./src/function-factory";

const manifest = Manifest.defineManifest(functionFactory, {
  version: "2",
  name: "example",
  functions: [{ name: "on_event", description: "Process an event" }],
});
const yaml = Manifest.toYaml(manifest);
```

Keep the factory's literal keys: widening it to `Record<string, ...>` loses the
compile-time function-reference guarantee. Runtime validation remains a backstop.

Workflow operation default ports use the platform's static schema shape:

```ts
operations: [{
  name: "weather",
  display_name: "Weather",
  description: "Read the weather for a city.",
  slug: "weather",
  type: "action",
  function: "weather",
  inputs: { fields: [{
    name: "city",
    field_type: "enum",
    allowed_values: ["New York", "Chicago"],
    is_required: true,
    ui: { display_name: "City" },
  }] },
  outputs: { fields: [{
    name: "temperature",
    field_type: "double",
    ui: { display_name: "Temperature" },
  }] },
}]
```

`inputs` and `outputs` are optional for operations such as schema handlers. This package
models `fields` and `composites` using its existing supported field-type subset; it does
not claim the platform's entire custom-schema vocabulary. There are no `input_types` or
`output_types` operation properties in this contract.
For v2, leave `namespace` unset or empty. Custom values fail typechecking and generation.

## Custom objects

Use `customObjectFragment` for a snap-in-owned custom leaf. It supplies the validated
`app_fragment` discriminator, repeats the leaf type correctly, requires a valid display-ID
prefix, and rejects duplicate field names:

```ts
const delivery = Manifest.customObjectFragment({
  leafType: "webhook_delivery",
  idPrefix: "WHDEL",
  description: "Durable webhook deliveries.",
  fields: [{ name: "event_id", field_type: "text", is_required: true }],
});
```

`customObjectCreatedSource` builds the matching `custom_object_created` webhook source and
leaf filter. `customObjectScope(leafType, verb)` constructs the three-part service-account
scope without using the raw-scope escape hatch.

## Guarantees and escape hatches

- Typed field shapes and value domains catch spelling and value mistakes. Catalogs
  are snapshots; `rawScope`, `rawEventType`, and `rawConnectionType` are explicit
  escapes for valid values outside them.
- Function/source/keyring references are bound to declared values. Runtime generation
  checks uniqueness, additional references, and modeled platform length/count limits.
- `jqFilter`, boolean combinators, and field predicates compose escaped jq expressions.
  `fieldEquals` compares to a string constant; use `rawCondition` for another field or
  jq variable. `rawJqFilter` bypasses the builder and needs review.
- `sharedSecretHeaderPolicy` emits a fail-closed Rego policy for a custom webhook.
  When provided, `policy` requires `RegoPolicy`; `rawRegoPolicy` is the explicit bypass.
  Control characters and unsafe interpolation are rejected by the builder.
- `hmacSha256KeyringWebhook` returns the HMAC policy and its required event-source
  `connections` entry together. DevRev then injects the selected secret as the flat value
  `input.keyrings[connectionName].secret`; it is not nested under `organization`.

`config.policy` remains optional in the platform-mirroring types; `defineManifest`
does not require an authentication policy. The secure starter supplies one and refuses
a missing secret. Review every custom webhook source when authoring other manifests.

A `flow-custom-webhook` policy is the request authentication boundary. Prefer a declared
secret keyring plus `hmacSha256KeyringWebhook`, which keeps the secret value out of generated
YAML. A raw policy that reads `input.keyrings` without a matching event-source `connections`
entry will receive no secret. `config.parameters` is also available but embeds its values in
the manifest/setup metadata. Runtime payload decoding is still needed after authentication.

## What the checks do not prove

The static schema field-list test checks the fields represented in this package. It
does **not** compare against a live/upstream schema or detect upstream additions.
Generated-copy checks catch changes to reviewed YAML, not platform schema drift.
Catalog/limit snapshots can become stale; server `validate-manifest` is authoritative.
Platform-owned URL restrictions, name grammars, remote references, and runtime behavior
still require server validation and appropriate isolated live tests.

Inline skill typing was removed while the platform moves skills to external artifacts.
Do not extend that surface speculatively. Keep this package focused on actual consumer
needs.

Run `npm run verify` at the repository root for compile-time negative contracts,
runtime tests, lint, and generated manifests. Run `devrev snap_in_version validate-manifest`
on the generated manifest for separate, authenticated server validation.
